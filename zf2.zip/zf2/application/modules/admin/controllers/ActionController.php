<?php
class Admin_ActionController extends Zend_Controller_Action{
	
	public function init(){ 
        $this->view->BaseUrl=$this->_request->getBaseUrl();
    } 

    public function  preDispatch(){
 	
        $this->auth = Zend_Auth::getInstance();
        $this->identity = $this->auth->getIdentity();
 
        $username= $this->identity->user_username;
        $password= $this->identity->user_password;
 
        $users2 = new Admin_Model_UserAdmin();  
        if ($users2->num($username, $password)>0) {                     
        
        }else{
              $this->_redirect('/admin/login');exit;
        }

        //get user by user name
        $acl = new Zend_Acl();
        $datauser = $users2->loadUserAdminByUsername($username);

        //get list role_id from table acl by user id
        $modelacl = new Admin_Model_Acl();
        $dataacl = $modelacl->loadAclByUserId($datauser->user_id);

        // load list roles
        $role = new Admin_Model_Role();
        if($dataacl != null && sizeof($dataacl)>0){
            foreach($dataacl as $idrole){
                //load role by role id
                $datarole = $role->loadRoleByRoleId($idrole);
                if($datarole != null){
                    $acl->add(new Zend_Acl_Resource($datarole->module_controller));
                    $acl->addRole(new Zend_Acl_Role($username));
                    // if($group->group_name!="" && $module->modDirectory!="")
                    // {
                        $acl->allow($username, $datarole->module_controller);
                    //}
                }
                
            }
        }

        if($acl->isAllowed($username,$this->_request->getControllerName()))
        {
        
        }
        else
        {
        
            //$this->_redirect('admin18/vi/temp/denied');exit;
            $this->_redirect('/admin/login');exit;
        }


        //lay ra dc module
     }

    public function indexAction(){ 
         $action = new Admin_Model_Action();
         $data = $action->loadAction();
         $this->view->actions =  $data;
    } 
    
    public function testAction(){
        //$this->_helper->layout('homelayout')->disableLayout();
        $action = new Admin_Model_Action();
        $data = $action->loadActiveAction();
        $this->view->actions =  $data;

        $module = new Admin_Model_Module();
        $data = $module->loadActiveModule();
        $this->view->modules =  $data;

        $user = new Admin_Model_UserAdmin();
        $data = $user->loadActiveUserAdmin();
        $this->view->users = $data;
    }

    public function createAction(){
        $this->_helper->layout('layout')->disableLayout();

        // $filter = new Zend_Filter();
        // if ($this->getRequest()->isXmlHttpRequest()) {
        //     if ($this->getRequest()->isPost()) {
                $role_name = $this->getRequest()->getParam('role_name');
                $modules = $this->getRequest()->getParam('tomodule');
                $actions = $this->getRequest()->getParam('toaction');
                $users = $this->getRequest()->getParam('touser');

                $this->view->modules = $modules;
                $this->view->actions = $actions;
                $this->view->users = $users;

                $myArray = array();
                // $acl = new Zend_Acl();

                // $listResource = array();

                // if($users != null && sizeof($users)>0){
                //     foreach($users  as $u){
                        
                if($actions != null && sizeof($actions)){
                    foreach($actions as $act){
                        if($modules != null && sizeof($modules)>0){
                            foreach($modules as $modu){
                                $role = new Admin_Model_Role();
                                $data = array(
                                            //add new role
                                    'role_name' => $role_name,
                                    'role_action' => $role_name,
                                    'role_status' =>'1',
                                    'action_id'=> $act,
                                    'module_id' => $modu

                                );
                                $idrole = $role->insert($data);
                                array_push($myArray, $idrole);  

                                // $modulemodel = new Admin_Model_Module();
                                // $moduledata = $modulemodel->loadModuleByModuleId($modu);
                                // $acl->add(new Zend_Acl_Resource($moduledata->module_controller));  
                                // array_push($listResource,$moduledata->module_controller);
                            }
                        }
                    }
                }
                       
                //     }
                // }

                if($users != null && sizeof($users)>0){
                    foreach($users  as $u){
                        $moduleuseradmin = new Admin_Model_UserAdmin();
                        $datauser = $moduleuseradmin->loadUserAdminById($u);
                        $acl->addRole(new Zend_Acl_Role($datauser->user_username));
                        if($myArray != null && sizeof($myArray>0)){
                            foreach($myArray as $role)
                            $aclmodel = new Admin_Model_Acl();
                            $data = array(
                                        //add new role
                                'role_id'=> $role,
                                'user_id'=>$u       
                            );
                            $aclmodel->insert($data);
                            // if($listResource != null && sizeof($listResource>0)){
                            //     $acl->allow($datauser->user_username, $listResource);         
                            // }                   
                        }
                       // Zend_Registry::set('acl', $acl);
                    }
                }

                //$values = $_POST['tomodule'];
                // echo "<prev>";
                //     print_r($modules);
                // echo "</prev>";

                // echo "<prev>";
                //     print_r($actions);
                // echo "</prev>";

                // echo "<prev>";
                //     print_r($users);
                // echo "</prev>";
                
                
            //     $arrInput = $this->_request->getParams();
            //     $this->view->arrInput = $arrInput;

            //     if($this->view->parError == ''){
            //         //$cat = new Default_Model_CategoryTraining();
            //         // $data = array(                       
            //         //     'cat_train_quantity' => $filter->filter($arrInput['cat_train_quantity']),
            //         //     'cat_train_name' => $filter->filter($arrInput['cat_train_name']),
            //         //     'cat_train_active' => '1',
                        
            //         // );

            //         // $cat->insert($data);                   
            //         // $this->view->data = $data;
            //         // //exit;
            //    }   
               
               //$this->view->values = $values->toArray();
        //     }
        // }    
    }

}