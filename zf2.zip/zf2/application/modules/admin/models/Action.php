<?php

class Admin_Model_Action  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'action';

    protected $_primary = 'action_id'; 

    protected $_sequence = true;

    public function loadAction()
    {
        $select = $this->select()
                       ->from($this,array('action_id','action_name','action_actname','action_status'));                       
                        
        $row = $this->fetchAll($select);
        return $row;
    }

    public function loadActiveAction()
    {
        $select = $this->select()
                       ->from($this,array('action_id','action_name','action_actname'))
                       ->where('action_status = ?', '1');                            
                        
        $row = $this->fetchAll($select);
        return $row;
    }
}