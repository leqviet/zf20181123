<?php

class Admin_Model_Role  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'role';

    protected $_primary = 'role_id'; 

    protected $_sequence = true;

    // public function loadAction()
    // {
    //     $select = $this->select()
    //                    ->from($this,array('action_id','action_name','action_actname','action_status'));                       
                        
    //     $row = $this->fetchAll($select);
    //     return $row;
    // }

    public function loadRoleByRoleId($id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        // $select = new Zend_Db_Select($db);
        $query = $db->select()
            ->from("module", array('module_controller'))
            ->joinInner(
            'role',
            'role.module_id = module.module_id',
            array())  
            ->where('role.role_id = ?',$id)
            ->limit(1);   
                        
        return $db->fetchRow($query);
    }
}