<?php
// Customers controller 
class CustomersController extends Zend_Controller_Action
{
    public function init(){
        $this->view->BaseUrl=$this->_request->getBaseUrl();
    }

    public function  preDispatch(){
 	
        $this->auth = Zend_Auth::getInstance();
        $this->identity = $this->auth->getIdentity();
 
        $username= $this->identity->user_username;
        $password= $this->identity->user_password;
 
        $users2 = new Default_Model_UserAdmin();  
        if ($users2->num($username, $password)>0) {                     
        
        }else{
              $this->_redirect('/default/login');exit;
        }
     }

    //  public function convertDate($dateConvert){
    //     // $var = $filter->filter($arrInput['cus_identity_date']);
    //     $date = str_replace('/', '-', $dateConvert);
    //     $final =  date('Y-m-d', strtotime($date));
    //     return $final;
    //  }

    public function indexAction(){
        $city = new Default_Model_City();
        $data = $city->loadCity();
        $this->view->cities =  $data;

    }

    // public function testAction(){
    //     $this->_helper->layout('layout')->disableLayout();
    // }

   
    /*update password of useradmin*/
    public function updatepasswordAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {

                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if(Zend_Validate::is($arrInput['currentPass'],'NotEmpty')){
                    if(md5(trim($filter->filter($arrInput['currentPass']))) != ($filter->filter($arrInput['passwordold']))){
                        $this->view->parError = 'Mật khẩu hiện tại không trùng với hệ thống ';
                    }                   
                }

                if($this->view->parError == ''){ 
                    $customer = new Default_Model_UserAdmin();
                    $data = array(
                        'user_password' => md5(trim($filter->filter($arrInput['password']))),
                    );

                    $customer->update($data, 'user_id = '. (int)($filter->filter($arrInput['user_id'])));                   
                }        
            }
        }    

    }

    /*update password*/
    public function updatenewpasswordcustomerAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {

                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if($this->view->parError == ''){ 
                    $customer = new Default_Model_Customers();
                    $data = array(
                        'cus_password' => md5(trim($filter->filter($arrInput['password']))),
                    );

                    $customer->update($data, 'cus_id = '. (int)($filter->filter($arrInput['cus_id'])));                   
                }        
            }
        }    

    }


    /*update password of customer*/
    public function updatepasswordcustomerAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {

                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if(Zend_Validate::is($arrInput['currentPass'],'NotEmpty')){
                    if(md5(trim($filter->filter($arrInput['currentPass']))) != ($filter->filter($arrInput['passwordold']))){
                        $this->view->parError = 'Mật khẩu hiện tại không trùng với hệ thống ';
                    }                   
                }

                if($this->view->parError == ''){ 
                    $customer = new Default_Model_Customers();
                    $data = array(
                        'cus_password' => md5(trim($filter->filter($arrInput['password']))),
                    );

                    $customer->update($data, 'cus_id = '. (int)($filter->filter($arrInput['cus_id'])));                   
                }        
            }
        }    

    }
    

    /*update information of customer*/
    public function updateAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {

                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

   
                if(!Zend_Validate::is($arrInput['cus_id'],'NotEmpty')){
                    $this->view->parError = 'Bạn phải chọn luật sư để cập nhật thông tin!';
                }

                
                /* covert date cmnd*/
                // $cmnd = $filter->filter($arrInput['cus_identity_date']);
                // $date_cmnd = str_replace('/', '-', $cmnd);
                // $final_cmnd =  date('Y-m-d', strtotime($date_cmnd));

                 /* covert date birthday*/
                 $birthday = $filter->filter($arrInput['cus_birthday']);
                 $date_birthday = str_replace('/', '-', $birthday);
                 $final_birthday =  date('Y-m-d', strtotime($date_birthday));

                  /* covert date passport*/
                $passport = $filter->filter($arrInput['cus_passport_date']);
                $date_passport = str_replace('/', '-', $passport);
                $final_passport =  date('Y-m-d', strtotime($date_passport));

               if($this->view->parError == ''){ 
                    $customer = new Default_Model_Customers();
                    $data = array(
                        'cus_firstname'=> $filter->filter($arrInput['cus_firstname']),
                        'cus_lastname'=> $filter->filter($arrInput['cus_lastname']),
                        //'cus_identity_date' => $final_cmnd,
                        'cus_birthday' => $final_birthday,
                        'cus_passport_date' => $final_passport,
                        'cus_sex' => $filter->filter($arrInput['cus_sex']),
                        'cus_country' => $filter->filter($arrInput['cus_country']),
                        'cus_nation' => $filter->filter($arrInput['cus_nation']),
                        'cus_homephone' => $filter->filter($arrInput['cus_homephone']),
                        'cus_passport_card' => $filter->filter($arrInput['cus_passport_card']),
                        'cus_passport_place' => $filter->filter($arrInput['cus_passport_place']),
                        'cus_address_resident' => $filter->filter($arrInput['cus_address_resident']),
                        'cus_educations' => $filter->filter($arrInput['cus_educations']),
                        'cus_language_level' => $filter->filter($arrInput['cus_language_level']),
                        //'city_id' => $filter->filter($arrInput['city_id']),
                        'cus_lawyer_hcm' => $filter->filter($arrInput['cus_lawyer_hcm']),
                        'cus_fullname' => ($filter->filter($arrInput['cus_lastname']).' '.$filter->filter($arrInput['cus_firstname']))
                    );
                    $this->view->data = $data;
                    $customer->update($data, 'cus_id = '. (int)($filter->filter($arrInput['cus_id'])));                   
                }        
            }
        }    

    }

    /*create new customer*/
    public function createAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {
                
                    $arrInput = $this->_request->getParams();
                    $this->view->arrInput = $arrInput;

                   /* covert date cmnd*/
                    $cmnd = $filter->filter($arrInput['cus_identity_date']);
                    $date_cmnd = str_replace('/', '-', $cmnd);
                    $final_cmnd =  date('Y-m-d', strtotime($date_cmnd));

                    /* covert date birthday*/
                    $birthday = $filter->filter($arrInput['cus_birthday']);
                    $date_birthday = str_replace('/', '-', $birthday);
                    $final_birthday =  date('Y-m-d', strtotime($date_birthday));

                    /* covert date passport*/
                    $passport = $filter->filter($arrInput['cus_passport_date']);
                    $date_passport = str_replace('/', '-', $passport);
                    $final_passport =  date('Y-m-d', strtotime($date_passport)); 

                    /* covert date cus_joining_communist_youth*/
                    $cus_joining_communist_youth = $filter->filter($arrInput['cus_joining_communist_youth']);
                    $date_cus_joining_communist_youth = str_replace('/', '-', $cus_joining_communist_youth);
                    $final_cus_joining_communist_youth =  date('Y-m-d', strtotime($date_cus_joining_communist_youth)); 

                    /* covert date cus_joining_communist_prepare*/
                    $cus_joining_communist_prepare= $filter->filter($arrInput['cus_joining_communist_prepare']);
                    $date_cus_joining_communist_prepare = str_replace('/', '-', $cus_joining_communist_prepare);
                    $final_cus_joining_communist_prepare =  date('Y-m-d', strtotime($date_cus_joining_communist_prepare)); 

                    /* covert date cus_joining_communist*/
                    $cus_joining_communist = $filter->filter($arrInput['cus_joining_communist']);
                    $date_cus_joining_communist = str_replace('/', '-', $cus_joining_communist);
                    $final_cus_joining_communist =  date('Y-m-d', strtotime($date_cus_joining_communist)); 



                if($this->view->parError == ''){
                    $customer = new Default_Model_Customers();
                    $currentdate = new Zend_Date();
                    $data = array(                       
                        'cus_firstname' => $filter->filter($arrInput['cus_firstname']),
                        'cus_lastname' => $filter->filter($arrInput['cus_lastname']),
                        'cus_sex' => $filter->filter($arrInput['cus_sex']),
                        'cus_country' => $filter->filter($arrInput['cus_country']),
                        'cus_birthday' => $final_birthday,
                        'cus_joining_communist_youth' => $final_cus_joining_communist_youth,
                        'cus_joining_communist_prepare' => $final_cus_joining_communist_prepare,
                        'cus_joining_communist' => $final_cus_joining_communist,
                        'cus_nation' => $filter->filter($arrInput['cus_nation']),
                        'cus_birthplace' => $filter->filter($arrInput['cus_birthplace']),
                        'cus_cellphone' => $filter->filter($arrInput['cus_cellphone']),  
                        'cus_homephone' => $filter->filter($arrInput['cus_homephone']),  
                        'cus_identity_card' => $filter->filter($arrInput['cus_identity_card']), 
                        'cus_identity_place' => $filter->filter($arrInput['cus_identity_place']),
                        'cus_identity_date' => $final_cmnd,
                        'cus_passport_card' => $filter->filter($arrInput['cus_passport_card']),
                        'cus_passport_place' => $filter->filter($arrInput['cus_passport_place']),
                        'cus_passport_date' => $final_passport,
                        'cus_address_resident' => $filter->filter($arrInput['cus_address_resident']),
                        'cus_educations' => $filter->filter($arrInput['cus_educations']),
                        //'cus_member' => $cus_member
                        'cus_language_level' => $filter->filter($arrInput['cus_language_level']),
                        'cus_date_created' => $currentdate->toString('YYYY-MM-dd HH:mm:ss'),
                        'city_id' => $filter->filter($arrInput['city_id']),                                             
                        'cus_username' => $filter->filter($arrInput['cus_username']),
                        'cus_password' => md5(trim($filter->filter($arrInput['cus_password']))),
                        'cus_fullname' => ($filter->filter($arrInput['cus_lastname']).' '.$filter->filter($arrInput['cus_firstname']))
                    );

                    $customer->insert($data);
                    //$idcustomer = $customer->insert($data);                   
                    //$this->view->idcustomer = $idcustomer;
                    if($filter->filter($arrInput['submittype']) == 'intership'){
                        $this->view->link = 'fee/intership';
                        $this->view->linkName = 'Đi đến trang tạo phí tập sự';

                    }else if($filter->filter($arrInput['submittype']) == 'joining'){
                        $this->view->link = 'fee/joining';
                        $this->view->linkName = 'Đi đến trang tạo phí gia nhập';
                    }
                    //exit;
               }        
            }
        }    
    }

    /*search customer*/
    public function searchAction()
    {
        $this->_helper->layout('homelayout')->disableLayout();    
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {
    
                $q=$this->getRequest()->getParam('searchword');
                $search = new Default_Model_Customers();
                $result = $search->searchByCellPhoneOrIdentityCardOrName($q);     
                $this->view->resultSearch = $result;
                $this->view->q = $q;
    
            }
        } 
    
    }

    /*page update information of customer*/
    public function detailsAction(){ 
        $city = new Default_Model_City();
        $data = $city->loadCity();
        $this->view->cities =  $data;
    }

    public function detailAction(){   
        $this->_helper->layout('homelayout')->disableLayout();
        $customer = new Default_Model_Customers();   
        $q = $this->getRequest()->getParam('searchword');
        $data = $customer->getCustomer($q);
        echo json_encode($data);
        exit; 
    }

    /* show form add new customer*/
    public function addAction(){
        //$this->_helper->layout('homelayout')->disableLayout();
    }

    /*validate phone and id card number and fullname*/
    public function validateAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $customer = new Default_Model_Customers();   
        $type = $this->getRequest()->getParam('type');
        $data = $this->getRequest()->getParam('data');
        
        if($type == 'username'){
            echo $customer->validateUsernameCustomer($type,$data);
            exit;
        } 

        $result = $customer->validateCustomer($type,$data); 
        $this->view->result = $result;

       
        
        if($result != null && $result['cus_cellphone'] != null){
           // echo $result['cus_cellphone'];
           echo json_encode($result);
        }
        exit;
    }

    /* change password for login user*/
    public function changepassAction(){
        $this->auth = Zend_Auth::getInstance();
        $this->identity = $this->auth->getIdentity();
 
        $username= $this->identity->user_username;
        $adminuser = new Default_Model_UserAdmin();
       
        $data = $adminuser->getUserAdminByUsername($username);

        $this->view->data = $data;
    }

    /*load list customer*/
    public function listcustomerAction(){
        $customer = new Default_Model_Customers();
        $data = $customer->loadCustomers();
        $this->view->data = $data;
    }

    /* change password for customer*/
    public function changepasswordAction(){
        $this->auth = Zend_Auth::getInstance();
        $this->identity = $this->auth->getIdentity();
    
        $username= $this->identity->user_username;
        $adminuser = new Default_Model_UserAdmin();
        
        $data = $adminuser->getUserAdminByUsername($username);

        $this->view->data = $data;
    }

//     public function searchAction(){
//         // $this->_helper->layout('homelayout')->disableLayout();

//         // // if ($this->getRequest()->isXmlHttpRequest()) {
//         // //     if ($this->getRequest()->isPost()) {
    
//         //          $q = $this->getRequest()->getParam('searchword');                
//         //          $search = new Admin_Model_Customers();
//         //          $result = $search->getCustomer($q);
               
//         //          //$this->view->data = $result;
//         //          $this->view->q = $q;
//         //         if($result){
//         //             $this->view->data = "Tồn tại số điện thoại ";
//         //         }else{
//         //             $this->view->data = "Không tồn tại số điện thoại ";     
//         //         }    
    
//         // //     }
//         // // }       
//    }
}