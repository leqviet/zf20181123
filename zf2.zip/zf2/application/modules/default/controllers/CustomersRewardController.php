<?php
// Customers controller 
class CustomersRewardController extends Zend_Controller_Action
{
    public function init(){
        $this->view->BaseUrl=$this->_request->getBaseUrl();
    }

    public function  preDispatch(){
 	
        $this->auth = Zend_Auth::getInstance();
        $this->identity = $this->auth->getIdentity();
 
        $username= $this->identity->user_username;
        $password= $this->identity->user_password;
 
        $users2 = new Default_Model_UserAdmin();  
        if ($users2->num($username, $password)>0) {                     
        
        }else{
              $this->_redirect('/default/login');exit;
        }
     }

     public function listAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $customerreward = new Default_Model_CustomersRewardDiscipline();  
        $cus_id = $this->getRequest()->getParam('cus_id'); 
        $data = $customerreward->loadCustomersRewardByCusId($cus_id);
        $this->view->customerrewards =  $data; 
    }
    
}
