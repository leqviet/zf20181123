<?php
// Fee controller 
class FeeController extends Zend_Controller_Action
{
    public function init(){
        $this->view->BaseUrl=$this->_request->getBaseUrl();
    }

    public function  preDispatch(){
 	
        $this->auth = Zend_Auth::getInstance();
        $this->identity = $this->auth->getIdentity();
 
        $username= $this->identity->user_username;
        $password= $this->identity->user_password;
 
        $users2 = new Default_Model_UserAdmin();  
        if ($users2->num($username, $password)>0) {                     
        
        }else{
              $this->_redirect('/default/login');exit;
        }
    }

    public function indexAction(){
        //$this->_helper->layout('homelayout')->disableLayout();
    }

    /* fee membership*/
    public function memberAction(){
        $categoryfreelawyer = new Default_Model_CategoryFeeLawyer();         
        $data = $categoryfreelawyer->loadCategoryFeeLawyer('member');
        $this->view->categoryfee =  $data;
    }

    /*fee internship*/
    public function intershipAction(){
        $categoryfreelawyer = new Default_Model_CategoryFeeLawyer();         
        $data = $categoryfreelawyer->loadCategoryFeeLawyer('intership');
        $this->view->categoryfee =  $data;

        $intershipnumber = new Default_Model_IntershipNumber();
        $data = $intershipnumber->loadIntershipNumberActive();
        $this->view->intershipdata = $data;
        
    }

    public function joiningAction(){
        $categoryfreelawyer = new Default_Model_CategoryFeeLawyer();         
        $data = $categoryfreelawyer->loadCategoryFeeLawyer('joining');
        $this->view->categoryfee =  $data;

        $joining = new Default_Model_Joining();
        $data_joining = $joining-> loadJoiningActive();
        $this->view->joiningdata = $data_joining;
    }

    /*load history fee by customer id*/
    public function listAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $paymentoffline = new Default_Model_PaymentLawyerOffline();   
        $cus_id = $this->getRequest()->getParam('cus_id');
        $data = $paymentoffline->loadPaymentLawyerOfflineByCusId($cus_id);
        $this->view->paymentofflines =  $data; 
    }

      /*load history fee intership by customer id*/
    public function listintershipAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $paymentoffline = new Default_Model_PaymentIntershipOffline();   
        $cus_id = $this->getRequest()->getParam('cus_id');
        $data = $paymentoffline->loadPaymentIntershipOfflineByCusId($cus_id);
        $this->view->paymentofflines =  $data; 
    }

      /*load history fee intership by customer id*/
    public function listjoiningAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $paymentoffline = new Default_Model_PaymentJoiningOffline();   
        $cus_id = $this->getRequest()->getParam('cus_id');
        $data = $paymentoffline->loadPaymentJoiningOfflineByCusId($cus_id);
        $this->view->paymentofflines =  $data; 
    }
    
    /*load list history fee*/
    public function confirmfeelistAction(){
        //$this->_helper->layout('homelayout')->disableLayout();
        $paymentoffline = new Default_Model_PaymentLawyerOffline();   
        $data = $paymentoffline->loadPaymentLawyerOffline();
        $this->view->paymentofflines =  $data; 

        $paymentjoiningoffline = new Default_Model_PaymentJoiningOffline();   
        $data = $paymentjoiningoffline->loadPaymentJoiningOffline();
        $this->view->paymentjoiningofflines =  $data; 

        $paymentintershipoffline = new Default_Model_PaymentIntershipOffline();   
        $data = $paymentintershipoffline->loadPaymentIntershipOffline();
        $this->view->paymentintershipofflines =  $data;       
    }

    public function detailconfirmfeeAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $paymentoffline = new Default_Model_PaymentLawyerOffline();   
        $id = $this->getRequest()->getParam('id');
        $data = $paymentoffline->loadPaymentLawyerOfflinegById($id);
        $this->view->paymentofflinedata =  $data; 
    }

     /*create fee memberr*/
     public function createfeejoiningAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {
                //$request = $this->getRequest();
                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if(!Zend_Validate::is($arrInput['cus_id'],'NotEmpty')){
                    $this->view->parError = 'Bạn phải chọn luật sư để tạo phí gia nhập!';
                }
    
               
               if($this->view->parError == ''){
                    $date = new Zend_Date();
                    $law_num = new Default_Model_LawyerNumber();
                                    
                    // $mil = $filter->filter($arrInput['regis_date']);
                    // $seconds = $mil / 1000;
                    // $time_regis_date =  date("Y-m-d H:m:s", $seconds);

                    //format 2018-10-20 18:59:00 YYYY-MM-dd HH:mm:ss
                    $data = array(   
                        //'month'=>$filter->filter($arrInput['month']),   
                        'law_fromdate' => $filter->filter($arrInput['regis_date']),
                        'law_enddate' => '',
                        'category_fee_lawyer_id' => $filter->filter($arrInput['category_fee_lawyer_id']),
                     );

                    $lawnum_id = $law_num->insert($data);

                    $billoffline = new Default_Model_BillFeeOffline();

                    $data_lawyernumber = array(
                        'lawnum_id' => $lawnum_id,
                        'cus_id' => $filter->filter($arrInput['cus_id']),
                        'bill_feeoffline_seria' => 'test'
                    );
                    $bill_feeoffline_id = $billoffline ->insert($data_lawyernumber);  
                    
                    
                    $paymentoffline = new Default_Model_PaymentJoiningOffline();

                    $data_paymentoffline = array(
                        'payment_joining_off_code' => $paymentoffline->generationCode('PGN','OFFLINE'),
                        'bill_feeoffline_id' => $bill_feeoffline_id,
                        'payment_joining_off_status' => '0',
                        'payment_joining_off_created_date' => $date->toString('YYYY-MM-dd HH:mm:ss'),
                        'amount' =>  $filter->filter($arrInput['amount'])
                    );
                    $paymentoffline ->insert($data_paymentoffline);  
                                      
                 }                   
             }
         }    
    }


    /*create fee memberr*/
    public function createAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {
                //$request = $this->getRequest();
                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if(!Zend_Validate::is($arrInput['cus_id'],'NotEmpty')){
                    $this->view->parError = 'Bạn phải chọn luật sư để tạo phí thành viên!';
                }
               
               if($this->view->parError == ''){
                    $date = new Zend_Date();
                    $law_num = new Default_Model_LawyerNumber();
                                    
                    $mil = $filter->filter($arrInput['regis_date']);
                    $seconds = $mil / 1000;
                    $time_regis_date =  date("Y-m-d H:m:s", $seconds);

                    //format 2018-10-20 18:59:00 YYYY-MM-dd HH:mm:ss
                    $data = array(               
                        'month' => $filter->filter($arrInput['month']),
                        'law_fromdate' => $time_regis_date,
                        //'law_enddate' => '',
                        'category_fee_lawyer_id' => $filter->filter($arrInput['category_fee_lawyer_id']),
                     );

                    //$this->view->result = $data;

                    $lawnum_id = $law_num->insert($data);

                    $billoffline = new Default_Model_BillFeeOffline();

                    $data_lawyernumber = array(
                        'lawnum_id' => $lawnum_id,
                        'cus_id' => $filter->filter($arrInput['cus_id']),
                        'bill_feeoffline_seria' => 'test'
                    );
                    $bill_feeoffline_id = $billoffline ->insert($data_lawyernumber);  
                    
                    
                    $paymentoffline = new Default_Model_PaymentLawyerOffline();

                    $data_paymentoffline = array(
                        'payment_lawyer_off_code' => $paymentoffline->generationCode('PTV','OFFLINE'),
                        'bill_feeoffline_id' => $bill_feeoffline_id,
                        'payment_lawyer_off_status' => '0',
                        'payment_lawyer_off_created_date' => $date->toString('YYYY-MM-dd HH:mm:ss'),
                        'amount' => $filter->filter($arrInput['amount'])
                    );
                    $paymentoffline ->insert($data_paymentoffline);  
                                      
                 }                   
             }
         }    
    }

    public function createfeeintershipAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {
                //$request = $this->getRequest();
                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if(!Zend_Validate::is($arrInput['cus_id'],'NotEmpty')){
                    $this->view->parError = 'Bạn phải chọn luật sư để tạo phí tập sự!';
                }

                if(Zend_Validate::is($arrInput['cus_id'],'NotEmpty')){
                    $cus_id = $arrInput['cus_id'];
                    $db = Zend_Db_Table::getDefaultAdapter();
                    $select = new Zend_Db_Select($db);
                    $select->from('intership', array('inter_id','cus_id'))
                    ->joinInner(
                        'intership_number',
                        'intership_number.intership_number_id = intership.intership_number_id',
                        array('intership_number_enddate'))   
                    ->where('intership.cus_id = ?',$cus_id)
                    ->order('inter_id desc')
                    ->limit(1);
                    
                    $resultSet = $db->fetchRow($select); 
                    
               
                    if($resultSet['inter_id'] == null){
                        $this->view->parError = 'Bạn không thể đóng phí tập sự khi chưa được thêm vào đợt tập sự. Bạn phải thêm vào đợt tập sự, trước khi đóng phí.' ;   
                    }else{
                        // if($resultSet['intership_number_enddate'] != null && strtotime($resultSet['intership_number_enddate']) + 60 > time()) {
                        //     $this->view->parError = 'Hiện tại đợt tập sự của bạn chưa kết thúc. Bạn chưa được thêm vào đợt tập sự mới.';
                        // }                         
                    }
                                      
                }             
               
               if($this->view->parError == ''){
                    $date = new Zend_Date();
                    $law_num = new Default_Model_LawyerNumber();
                                    
                    $mil = $filter->filter($arrInput['regis_date']);
                    $seconds = $mil / 1000;
                    $time_regis_date =  date("Y-m-d H:m:s", $seconds);

                    //format 2018-10-20 18:59:00 YYYY-MM-dd HH:mm:ss
                    $data = array(               
                        //'month' => $filter->filter($arrInput['category_fee_lawyer_id']),
                        'law_fromdate' => $time_regis_date,
                        //'law_enddate' => '',
                        'category_fee_lawyer_id' => $filter->filter($arrInput['category_fee_lawyer_id']),
                     );

                    //$this->view->result = $data;

                    $lawnum_id = $law_num->insert($data);

                    $billoffline = new Default_Model_BillFeeOffline();

                    $data_lawyernumber = array(
                        'lawnum_id' => $lawnum_id,
                        'cus_id' => $filter->filter($arrInput['cus_id']),
                        'bill_feeoffline_seria' => 'test'
                    );
                    $bill_feeoffline_id = $billoffline ->insert($data_lawyernumber);  
                    
                    
                    // create payment intership
                    $paymentoffline = new Default_Model_PaymentIntershipOffline();

                    $data_paymentoffline = array(
                        'payment_inter_off_code' => $paymentoffline->generationCode('PTS','OFFLINE'),
                        'bill_feeoffline_id' => $bill_feeoffline_id,
                        'payment_inter_off_status' => '0',
                        'payment_inter_off_created_date' => $date->toString('YYYY-MM-dd HH:mm:ss'),
                        'amount' =>  $filter->filter($arrInput['amount'])
                    );
                    $paymentoffline ->insert($data_paymentoffline);  
                                      
                 }                   
             }
         }    
    }

    public function detailjoiningpaymentAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $paymentjoiningoffline = new Default_Model_PaymentJoiningOffline();   
        $payment_joining_off_id = $this->getRequest()->getParam('payment_joining_off_id');
        $data = $paymentjoiningoffline->loadPaymentJoiningOfflineById($payment_joining_off_id);
        $this->view->paymentjoiningofflinedata =  $data; 
    }

    public function updatejoiningpaymentAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {

                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if($this->view->parError == ''){ 
                    $payment = new Default_Model_PaymentJoiningOffline();
                    $data = array(                 
                        'payment_joining_off_status'=> $filter->filter($arrInput['payment_joining_off_status'])                      
                    );
                    //$this->view->data = $data;
                    $payment->update($data, 'payment_joining_off_id = '. (int)($filter->filter($arrInput['payment_joining_off_id'])));                   
                }        
            }
        }    

    }

    public function detailmemberpaymentAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $paymentlawyertrainingoffline = new Default_Model_PaymentLawyerOffline();   
        $payment_lawyer_off_id = $this->getRequest()->getParam('payment_lawyer_off_id');
        $data = $paymentlawyertrainingoffline->loadPaymentLawyerOfflineById($payment_lawyer_off_id);
        $this->view->paymentlawyerofflinedata =  $data; 
        
    }

    public function updatememberpaymentAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {

                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if($this->view->parError == ''){ 
                    $payment = new Default_Model_PaymentLawyerOffline();
                    $data = array(                 
                        'payment_lawyer_off_status'=> $filter->filter($arrInput['payment_lawyer_off_status'])                      
                    );
                    //$this->view->data = $data;
                    $payment->update($data, 'payment_lawyer_off_id = '. (int)($filter->filter($arrInput['payment_lawyer_off_id'])));                   
                }        
            }
        }    

    }



    public function detailintershippaymentAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $paymentintershipoffline = new Default_Model_PaymentIntershipOffline();   
        $payment_inter_off_id = $this->getRequest()->getParam('payment_inter_off_id');
        $data = $paymentintershipoffline->loadPaymentIntershipOfflineById($payment_inter_off_id);
        $this->view->paymentintershipofflinedata =  $data; 
        
    }

    public function updateintershippaymentAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {

                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if($this->view->parError == ''){ 
                    $payment = new Default_Model_PaymentIntershipOffline();
                    $data = array(                 
                        'payment_inter_off_status'=> $filter->filter($arrInput['payment_inter_off_status'])                      
                    );
                    //$this->view->data = $data;
                    $payment->update($data, 'payment_inter_off_id = '. (int)($filter->filter($arrInput['payment_inter_off_id'])));                   
                }        
            }
        }    

    }

    public function differentAction(){
        $categoryfreelawyer = new Default_Model_CategoryFeeLawyer();         
        $data = $categoryfreelawyer->loadCategoryFeeLawyer('different');
        $this->view->categoryfee =  $data;
    }

    /*create fee memberr*/
    public function createfeedifferentAction(){
            $this->_helper->layout('layout')->disableLayout();
    
            $filter = new Zend_Filter();
            if ($this->getRequest()->isXmlHttpRequest()) {
                if ($this->getRequest()->isPost()) {
                    //$request = $this->getRequest();
                    $arrInput = $this->_request->getParams();
                    $this->view->arrInput = $arrInput;    
        
                   
                   if($this->view->parError == ''){
                        $date = new Zend_Date();
                        $law_num = new Default_Model_LawyerNumber();
                                        
                        $data = array(   
                            //'month'=>$filter->filter($arrInput['month']),   
                            'law_fromdate' => $filter->filter($arrInput['regis_date']),
                            'law_enddate' => '',
                            'category_fee_lawyer_id' => $filter->filter($arrInput['category_fee_lawyer_id']),
                            'amount' =>  $filter->filter($arrInput['amount'])
                        );
    
                        $lawnum_id = $law_num->insert($data);
    
                        $billoffline = new Default_Model_BillFeeOffline();
    
                        $data_lawyernumber = array(
                            'lawnum_id' => $lawnum_id,
                            //'cus_id' => $filter->filter($arrInput['cus_id']),
                            'bill_feeoffline_seria' => 'test',
                            'community' => $filter->filter($arrInput['community'])

                        );
                        $bill_feeoffline_id = $billoffline ->insert($data_lawyernumber);  
                        
                        
                        $paymentoffline = new Default_Model_PaymentOffline();
    
                        $data_paymentoffline = array(
                            'payment_off_code' => $paymentoffline->generationCode('PTT','OFFLINE'),
                            'bill_feeoffline_id' => $bill_feeoffline_id,
                            'payment_off_status' => '0',
                            'payment_off_created_date' => $date->toString('YYYY-MM-dd HH:mm:ss'),
                            'amount' => $filter->filter($arrInput['amount']),
                            'reason' => $filter->filter($arrInput['reason'])
                        );
                        $paymentoffline ->insert($data_paymentoffline);  
                                          
                     }                   
                 }
             }    
        }

    public function printlawyerfeeAction(){
         $this->_helper->layout('homelayout')->disableLayout();
        $paymentlawyertrainingoffline = new Default_Model_PaymentLawyerOffline();   
        $payment_lawyer_off_id = $this->getRequest()->getParam('payment_lawyer_off_id');
        $data = $paymentlawyertrainingoffline->loadPaymentLawyerOfflineById($payment_lawyer_off_id);
        $this->view->paymentlawyerofflinedata =  $data; 
    }    

    public function printjoiningfeeAction(){
       $this->_helper->layout('homelayout')->disableLayout();
       $paymentjoiningoffline = new Default_Model_PaymentJoiningOffline();   
       $payment_joining_off_id = $this->getRequest()->getParam('payment_joining_off_id');
       $data = $paymentjoiningoffline->loadPaymentJoiningOfflineById($payment_joining_off_id);
       $this->view->paymentjoiningofflinedata =  $data; 
   }    

   public function printintershipfeeAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $paymentintershipoffline = new Default_Model_PaymentIntershipOffline();   
        $payment_inter_off_id = $this->getRequest()->getParam('payment_inter_off_id');
        $data = $paymentintershipoffline->loadPaymentIntershipOfflineById($payment_inter_off_id);
        $this->view->paymentintershipofflinedata =  $data; 
    }    
}