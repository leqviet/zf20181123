<?php
// Intership controller 
class IntershipController extends Zend_Controller_Action
{
    public function init(){
        $this->view->BaseUrl=$this->_request->getBaseUrl();
    }

    public function  preDispatch(){
 	
        $this->auth = Zend_Auth::getInstance();
        $this->identity = $this->auth->getIdentity();
 
        $username= $this->identity->user_username;
        $password= $this->identity->user_password;
 
        $users2 = new Default_Model_UserAdmin();  
        if ($users2->num($username, $password)>0) {                     
        
        }else{
              $this->_redirect('/default/login');exit;
        }
     }

 

    public function detailAction(){   
        $this->_helper->layout('homelayout')->disableLayout();
        $intership = new Default_Model_Intership();   
        $intership_id = $this->getRequest()->getParam('inter_id');
        $data = $intership->loadIntershipByInterId($intership_id);
        $this->view->intershipdata = $data;

        // echo "<prev>";
        //     print_r($this->view->intershipdata);
        // echo "</prev>";

        //intership number
        $intershipnumber = new Default_Model_IntershipNumber();
        $data = $intershipnumber->loadIntershipNumberActive();
        $this->view->intershipnumbers =  $data;

        //load lawyer
        // $lawyer = new Default_Model_Lawyer();
        // $data = $lawyer->loadLawyerActive();
        // $this->view->lawyers =  $data;
      
    } 


    public function updateAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {

                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

               if($this->view->parError == ''){ 
                    $intership = new Default_Model_Intership();
                    $data = array(
                        'intership_number_id'=> $filter->filter($arrInput['intership_number_id'])
                    );
                    //$this->view->data = $data;
                    $intership->update($data, 'inter_id = '. (int)($filter->filter($arrInput['inter_id'])));                   
                }        
            }
        }    

    }

    public function listAction(){
        $this->_helper->layout('homelayout')->disableLayout();
         $intership = new Default_Model_Intership();   
         $cus_id = $this->getRequest()->getParam('cus_id');
         $data = $intership->loadIntershipByCusId($cus_id);
         $this->view->interships =  $data;  
    }

    public function indexAction(){
        $intershipnumber = new Default_Model_IntershipNumber();
        $this->view->intershipnumberdata = $intershipnumber->loadInterhipNumber();
    }

    public function addAction(){
        // $cus = new Default_Model_Customers();
        // $data = $cus->loadCustomers();
        // $this->view->customers =  $data;
        
        //load list lawyer
        $lawyer = new Default_Model_Lawyer();
        $data = $lawyer->loadLawyer();
        $this->view->lawyers = $data;

        $intershipnum = new Default_Model_IntershipNumber();
        $data = $intershipnum->loadInterhipNumber();
        $this->view->internum =  $data;

    }

    public function addintershipnumberAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {
                
                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if($this->view->parError == ''){
                    $intershipnumber = new Default_Model_IntershipNumber();
                    $data = array(                       
                        'intership_number_startdate' => $filter->filter($arrInput['intership_number_startdate']),
                        'intership_number_enddate' => $filter->filter($arrInput['intership_number_enddate']),
                        'intership_number_createddate' => $filter->filter($arrInput['intership_number_enddate']),
                        'intership_number_name' => $filter->filter($arrInput['intership_number_name']),
                        'intership_number_status' => '1'                      
                        
                    );

                    $intershipnumber->insert($data);                   
                   
               }        
            }
        }    

    }

    /*create new customer*/
    public function createAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {
                //$request = $this->getRequest();
                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if(!Zend_Validate::is($arrInput['cus_id'],'NotEmpty')){
                    $this->view->parError = 'Bạn phải chọn luật sư để tạo luật sư tập sự! <br>';
                }
    
                if(!Zend_Validate::is($arrInput['law_id'],'NotEmpty')){
                    $this->view->parError = 'Bạn phải người hướng dẫn cho luật sư tập sự! <br>';
                }

                if(Zend_Validate::is($arrInput['law_id'],'NotEmpty') && Zend_Validate::is($arrInput['cus_id'],'NotEmpty')){
                    if($arrInput['law_id'] == $arrInput['cus_id']){
                        $this->view->parError = 'Bạn không thể quan lý chính bạn! <br>';
                    } 
                } 

                if(Zend_Validate::is($arrInput['cus_id'],'NotEmpty')){
                    $cus_id = $arrInput['cus_id'];
                    $db = Zend_Db_Table::getDefaultAdapter();
                    $select = new Zend_Db_Select($db);
                    $select->from('intership', array('inter_id','cus_id'))
                    ->joinInner(
                        'intership_number',
                        'intership_number.intership_number_id = intership.intership_number_id',
                        array('intership_number_enddate'))   
                    ->where('intership.cus_id = ?',$cus_id)
                    ->order('inter_id desc')
                    ->limit(1);
                    
                    $resultSet = $db->fetchRow($select); 
                    
                    if($resultSet['intership_number_enddate'] != null && (strtotime($resultSet['intership_number_enddate']) + 60 > time())) {
                        $this->view->parError = 'Hiện tại đợt tập sự của bạn chưa kết thúc.';
                    }                   
                }                
                 
               if($this->view->parError == ''){
                    $date = new Zend_Date();
                    $intership = new Default_Model_Intership();
                                    
                    $mil = $filter->filter($arrInput['inter_regis_date']);
                    $seconds = $mil / 1000;
                    $time_regis_date =  date("Y-m-d H:m:s", $seconds);

                    //format 2018-10-20 18:59:00 YYYY-MM-dd HH:mm:ss
                    $data = array(                           
                        // 'inter_code' => $intership->generationCode('PTS','OFFLINE'),
                        'inter_code' => 'testcode',
                        'inter_regis_date' => $time_regis_date,
                        'inter_created_date' => $date->toString('YYYY-MM-dd HH:mm:ss'),
                        'cus_id' => $filter->filter($arrInput['cus_id']),
                        'intership_number_id' => $filter->filter($arrInput['intership_number_id'])
                     );

                    //$this->view->result = $data;

                    $idintership = $intership->insert($data);

                    $guidelaw = new Default_Model_GuideLaw();

                    $data_guidelaw = array(                        
                        'law_id'=> $filter->filter($arrInput['law_id']),
                        'inter_id'=> $idintership,
                    );

                    $guidelaw->insert($data_guidelaw);
                   
                    //$this->view->resultid = $id;
                   
                 }                   
             }
         }    
    }


}
