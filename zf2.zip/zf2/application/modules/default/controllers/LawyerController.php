<?php
// Intership controller 
class LawyerController extends Zend_Controller_Action
{
    public function init(){
        $this->view->BaseUrl=$this->_request->getBaseUrl();
    }

    public function  preDispatch(){
 	
        $this->auth = Zend_Auth::getInstance();
        $this->identity = $this->auth->getIdentity();
 
        $username= $this->identity->user_username;
        $password= $this->identity->user_password;
 
        $users2 = new Default_Model_UserAdmin();  
        if ($users2->num($username, $password)>0) {                     
        
        }else{
              $this->_redirect('/default/login');exit;
        }
    }

    public function indexAction(){
        //$this->_helper->layout('homelayout')->disableLayout();

        //load list status law
        $lawstatus = new Default_Model_LawStatus();
        $data = $lawstatus->loadLawStatus();
        $this->view->status =  $data;

        // // //load list 
        $organizations = new Default_Model_OrganizationLaw();
        $data = $organizations->loadOrganzationLaw();
        $this->view->organizations_data =  $data;

        // // //load list 
        $activitys = new Default_Model_ActivityLaw();
        $data = $activitys->loadActivityLaw();
        $this->view->activitys_data =  $data;


        
    }

    public function detailAction(){   
        $this->_helper->layout('homelayout')->disableLayout();
        $lawyer = new Default_Model_Lawyer();   
        $law_id = $this->getRequest()->getParam('law_id');
        $data = $lawyer->loadLawyerByLawId($law_id);
        $this->view->lawyerdata = $data;

        //load list status law
        $lawstatus = new Default_Model_LawStatus();
        $data = $lawstatus->loadLawStatus();
        $this->view->status =  $data;

        // // //load list 
        $organizations = new Default_Model_OrganizationLaw();
        $data = $organizations->loadOrganzationLaw();
        $this->view->organizations_data =  $data;

        // // //load list 
        $activitys = new Default_Model_ActivityLaw();
        $data = $activitys->loadActivityLaw();
        $this->view->activitys_data =  $data;
    }

    public function listAction(){
        $this->_helper->layout('homelayout')->disableLayout();
         $lawyer = new Default_Model_Lawyer();   
         $cus_id = $this->getRequest()->getParam('cus_id');
         $data = $lawyer->loadLawyerByCusId($cus_id);
         $this->view->lawyers =  $data; 
    }

    /*update information of customer*/
    public function updateAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {

                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

               if($this->view->parError == ''){ 
                    $lawyer = new Default_Model_Lawyer();
                    $data = array(
                        'law_code'=> $filter->filter($arrInput['law_code']),
                        'act_id'=> $filter->filter($arrInput['act_id']),
                        'law_certfication_no'=> $filter->filter($arrInput['law_certfication_no']),
                        'organ_lid'=> $filter->filter($arrInput['organ_lid']),
                        'lawstatus_id'=> $filter->filter($arrInput['lawstatus_id']),
                        'law_joining_number'=> $filter->filter($arrInput['law_joining_number']),
                        'law_organ_old'=> $filter->filter($arrInput['law_organ_old']),
                        'law_type'=> $filter->filter($arrInput['law_type'])
                    );
                    //$this->view->data = $data;
                    $lawyer->update($data, 'law_id = '. (int)($filter->filter($arrInput['law_id'])));                   
                }        
            }
        }    

    }

     /*create new customer*/
     public function createAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {
                
                    $arrInput = $this->_request->getParams();
                    $this->view->arrInput = $arrInput;

                    if(!Zend_Validate::is($arrInput['cus_id'],'NotEmpty')){
                        $this->view->parError = 'Bạn phải chọn luật sư để tạo luật sư chính thức! ';
                    }

                   /* covert date cmnd*/
                    $law_code_createdate = $filter->filter($arrInput['law_code_createdate']);
                    $date_law = str_replace('/', '-', $law_code_createdate);
                    $final_law_code_createdate =  date('Y-m-d', strtotime($date_law));

                    /* covert date birthday*/
                    $law_certification_createdate = $filter->filter($arrInput['law_certification_createdate']);
                    $date_law_certification_createdate = str_replace('/', '-', $law_certification_createdate);
                    $final_law_certification_createdate =  date('Y-m-d', strtotime($date_law_certification_createdate));

                    $law_organ_old = NULL;
                    if(isset($arrInput['law_organ_old'])){
                        $law_organ_old  = $filter->filter($arrInput['law_organ_old']);
                    }

                    $law_joining_number = NULL;
                    if(isset($arrInput['law_joining_number'])){
                        $law_joining_number = $filter->filter($arrInput['law_joining_number']);
                    }

                if($this->view->parError == ''){
                    $lawyer = new Default_Model_Lawyer();
                    //$currentdate = new Zend_Date();
                    $data = array(       
                        // 'law_id'=> '1',                
                        'cus_id' => $filter->filter($arrInput['cus_id']),
                        'law_code' => $filter->filter($arrInput['law_code']),                        
                        'law_code_createdate' => $final_law_code_createdate,
                        'act_id' => $filter->filter($arrInput['act_id']),
                        'law_certfication_no' => $filter->filter($arrInput['law_certfication_no']),
                        'law_certification_createdate' =>  $final_law_certification_createdate,
                        'organ_lid' =>  $filter->filter($arrInput['organ_lid']),
                        'lawstatus_id' =>  $filter->filter($arrInput['lawstatus_id']),
                        'law_type' => $filter->filter($arrInput['joiningvalue']) == 'organ' ? 'Luật sư tại đoàn' :'Luật sư đoàn khác chuyển đến',
                        'law_joining_number' =>  $law_joining_number,
                        'law_organ_old' =>  $law_organ_old
                      
                    );

                    $lawyer->insert($data);                   
                    $this->view->data = $data;
                    //exit;
               }        
            }
        }    
    }

 
}    