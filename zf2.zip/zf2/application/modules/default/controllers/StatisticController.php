<?php
// Customers controller 
class StatisticController extends Zend_Controller_Action
{
    public function init(){
        $this->view->BaseUrl=$this->_request->getBaseUrl();
    }

    public function  preDispatch(){
 	
        $this->auth = Zend_Auth::getInstance();
        $this->identity = $this->auth->getIdentity();
 
        $username= $this->identity->user_username;
        $password= $this->identity->user_password;
 
        $users2 = new Default_Model_UserAdmin();  
        if ($users2->num($username, $password)>0) {                     
        
        }else{
              $this->_redirect('/default/login');exit;
        }
     }

   

     public function activelawyerandintershipAction(){
         
     }

     public function listactivelawyerAction(){
        $lawyer = new Default_Model_Lawyer();
        $dataactivelawyer = $lawyer->loadLawyerActive();
        $this->view->dataactivelawyer = $dataactivelawyer;

     }

     public function activelawyerAction() {
        $this->_helper->layout('layout')->disableLayout();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $lawyer = new Default_Model_Lawyer();
        $data = $lawyer->loadLawyerActive();
            //Khởi tạo đối tượng
        $excel = new Default_Model_Excel();
            //Chọn trang cần ghi (là số từ 0->n)
        $excel->setActiveSheetIndex(0);
            //Tạo tiêu đề cho trang. (có thể không cần)
        $excel->getActiveSheet()->setTitle('Luật sư đang hoạt động');

            //Xét chiều rộng cho từng, nếu muốn set height thì dùng setRowHeight()
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);

            //Xét in đậm cho khoảng cột
        $excel->getActiveSheet()->getStyle('A1:I1')->getFont()->setBold(true);
        //Tạo tiêu đề cho từng cột
        //Vị trí có dạng như sau:
        /**
         * |A1|B1|C1|..|n1|
         * |A2|B2|C2|..|n1|
         * |..|..|..|..|..|
         * |An|Bn|Cn|..|nn|
         */
        $excel->getActiveSheet()->setCellValue('A1', 'Tên');
        $excel->getActiveSheet()->setCellValue('B1', 'Giới Tính');
        $excel->getActiveSheet()->setCellValue('C1', 'CMND');
        $excel->getActiveSheet()->setCellValue('D1', 'Số Điện Thoại');
        $excel->getActiveSheet()->setCellValue('E1', 'Mã số luật sư');
        $excel->getActiveSheet()->setCellValue('F1', 'Số chứng chỉ hành nghề');
        $excel->getActiveSheet()->setCellValue('G1', 'Tổ chức hành nghề');
        $excel->getActiveSheet()->setCellValue('H1', 'Loại luật sư');
        $excel->getActiveSheet()->setCellValue('I1', 'Tình trạng luật sư');
        // thực hiện thêm dữ liệu vào từng ô bằng vòng lặp
        // dòng bắt đầu = 2
        $numRow = 2;
        foreach($data as $row){
            $excel->getActiveSheet()->setCellValue('A'.$numRow, $row['cus_lastname'].' '.$row['cus_firstname']);
            if($row['cus_sex'] == 'nam'){
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nam');    
            }else{
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nữ');    
            }
                
            $excel->getActiveSheet()->setCellValue('C'.$numRow, $row['cus_identity_card']);
            $excel->getActiveSheet()->setCellValue('D'.$numRow, $row['cus_cellphone']);
            $excel->getActiveSheet()->setCellValue('E'.$numRow, $row['law_code']);
            $excel->getActiveSheet()->setCellValue('F'.$numRow, $row['law_certfication_no']);
            $excel->getActiveSheet()->setCellValue('G'.$numRow, $row['organ_name']);
            $excel->getActiveSheet()->setCellValue('H'.$numRow, $row['law_type']);
            $excel->getActiveSheet()->setCellValue('I'.$numRow, 'Đang hoạt động');
            $numRow++;
        }
        // Khởi tạo đối tượng PHPExcel_IOFactory để thực hiện ghi file
        // ở đây mình lưu file dưới dạng excel2007 và cho người dùng download luôn
        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="DS_LuatSu_DangHoatDong.xlsx"');
        PHPExcel_IOFactory::createWriter($excel, 'Excel2007')->save('php://output');
        return;
     }

     public function listmoveorgAction(){
        $lawyer = new Default_Model_Lawyer();
        $dataactivelawyer = $lawyer->loadLawyerByLawStatus(3);
        $this->view->dataactivelawyer = $dataactivelawyer;

     }

     //danh sách luật sư chuyển đoàn
     public function moveorgAction(){
        $this->_helper->layout('layout')->disableLayout();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $lawyer = new Default_Model_Lawyer();
        $data = $lawyer->loadLawyerByLawStatus(3);
            //Khởi tạo đối tượng
        $excel = new Default_Model_Excel();
            //Chọn trang cần ghi (là số từ 0->n)
        $excel->setActiveSheetIndex(0);
            //Tạo tiêu đề cho trang. (có thể không cần)
        $excel->getActiveSheet()->setTitle('Luật sư chuyển đoàn');

            //Xét chiều rộng cho từng, nếu muốn set height thì dùng setRowHeight()
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);

            //Xét in đậm cho khoảng cột
        $excel->getActiveSheet()->getStyle('A1:I1')->getFont()->setBold(true);
        
        //Tạo tiêu đề cho từng cột
        //Vị trí có dạng như sau:
        /**
         * |A1|B1|C1|..|n1|
         * |A2|B2|C2|..|n1|
         * |..|..|..|..|..|
         * |An|Bn|Cn|..|nn|
         */
        $excel->getActiveSheet()->setCellValue('A1', 'Tên');
        $excel->getActiveSheet()->setCellValue('B1', 'Giới Tính');
        $excel->getActiveSheet()->setCellValue('C1', 'CMND');
        $excel->getActiveSheet()->setCellValue('D1', 'Số Điện Thoại');
        $excel->getActiveSheet()->setCellValue('E1', 'Mã số luật sư');
        $excel->getActiveSheet()->setCellValue('F1', 'Số chứng chỉ hành nghề');
        $excel->getActiveSheet()->setCellValue('G1', 'Tổ chức hành nghề');
        $excel->getActiveSheet()->setCellValue('H1', 'Loại luật sư');
        $excel->getActiveSheet()->setCellValue('I1', 'Tình trạng luật sư');

        

        // thực hiện thêm dữ liệu vào từng ô bằng vòng lặp
        // dòng bắt đầu = 2
        $numRow = 2;
        foreach($data as $row){
            $excel->getActiveSheet()->setCellValue('A'.$numRow, $row['cus_firstname'].' '.$row['cus_lastname']);
            if($row['cus_sex'] == 'nam'){
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nam');    
            }else{
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nữ');    
            }
                
            $excel->getActiveSheet()->setCellValue('C'.$numRow, $row['cus_identity_card']);
            $excel->getActiveSheet()->setCellValue('D'.$numRow, $row['cus_cellphone']);
            $excel->getActiveSheet()->setCellValue('E'.$numRow, $row['law_code']);
            $excel->getActiveSheet()->setCellValue('F'.$numRow, $row['law_certfication_no']);
            $excel->getActiveSheet()->setCellValue('G'.$numRow, $row['organ_name']);
            $excel->getActiveSheet()->setCellValue('H'.$numRow, $row['law_type']);
            $excel->getActiveSheet()->setCellValue('I'.$numRow, 'Chuyển đoàn');
            $numRow++;
        }
        // Khởi tạo đối tượng PHPExcel_IOFactory để thực hiện ghi file
        // ở đây mình lưu file dưới dạng excel2007 và cho người dùng download luôn
        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="DS_LuatSu_ChuyenDoan.xlsx"');
        PHPExcel_IOFactory::createWriter($excel, 'Excel2007')->save('php://output');
        return;
     }

     public function listremovelawyernameAction(){
        $lawyer = new Default_Model_Lawyer();
        $dataactivelawyer = $lawyer->loadLawyerByLawStatus(5);
        $this->view->dataactivelawyer = $dataactivelawyer;
     }

     //danh sách luật sư rút tên
     public function removelawyernameAction(){
        $this->_helper->layout('layout')->disableLayout();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $lawyer = new Default_Model_Lawyer();
        $data = $lawyer->loadLawyerByLawStatus(5);
            //Khởi tạo đối tượng
        $excel = new Default_Model_Excel();
            //Chọn trang cần ghi (là số từ 0->n)
        $excel->setActiveSheetIndex(0);
            //Tạo tiêu đề cho trang. (có thể không cần)
        $excel->getActiveSheet()->setTitle('Luật sư rút tên');

            //Xét chiều rộng cho từng, nếu muốn set height thì dùng setRowHeight()
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);

            //Xét in đậm cho khoảng cột
        $excel->getActiveSheet()->getStyle('A1:I1')->getFont()->setBold(true);
        
        //Tạo tiêu đề cho từng cột
        //Vị trí có dạng như sau:
        /**
         * |A1|B1|C1|..|n1|
         * |A2|B2|C2|..|n1|
         * |..|..|..|..|..|
         * |An|Bn|Cn|..|nn|
         */
        $excel->getActiveSheet()->setCellValue('A1', 'Tên');
        $excel->getActiveSheet()->setCellValue('B1', 'Giới Tính');
        $excel->getActiveSheet()->setCellValue('C1', 'CMND');
        $excel->getActiveSheet()->setCellValue('D1', 'Số Điện Thoại');
        $excel->getActiveSheet()->setCellValue('E1', 'Mã số luật sư');
        $excel->getActiveSheet()->setCellValue('F1', 'Số chứng chỉ hành nghề');
        $excel->getActiveSheet()->setCellValue('G1', 'Tổ chức hành nghề');
        $excel->getActiveSheet()->setCellValue('H1', 'Loại luật sư');
        $excel->getActiveSheet()->setCellValue('I1', 'Tình trạng luật sư');

        

        // thực hiện thêm dữ liệu vào từng ô bằng vòng lặp
        // dòng bắt đầu = 2
        $numRow = 2;
        foreach($data as $row){
            $excel->getActiveSheet()->setCellValue('A'.$numRow, $row['cus_firstname'].' '.$row['cus_lastname']);
            if($row['cus_sex'] == 'nam'){
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nam');    
            }else{
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nữ');    
            }
                
            $excel->getActiveSheet()->setCellValue('C'.$numRow, $row['cus_identity_card']);
            $excel->getActiveSheet()->setCellValue('D'.$numRow, $row['cus_cellphone']);
            $excel->getActiveSheet()->setCellValue('E'.$numRow, $row['law_code']);
            $excel->getActiveSheet()->setCellValue('F'.$numRow, $row['law_certfication_no']);
            $excel->getActiveSheet()->setCellValue('G'.$numRow, $row['organ_name']);
            $excel->getActiveSheet()->setCellValue('H'.$numRow, $row['law_type']);
            $excel->getActiveSheet()->setCellValue('I'.$numRow, 'Rút tên');
            $numRow++;
        }
        // Khởi tạo đối tượng PHPExcel_IOFactory để thực hiện ghi file
        // ở đây mình lưu file dưới dạng excel2007 và cho người dùng download luôn
        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="DS_LuatSu_RutTen.xlsx"');
        PHPExcel_IOFactory::createWriter($excel, 'Excel2007')->save('php://output');
        return;
     }

     public function listdielawyerAction(){
        $lawyer = new Default_Model_Lawyer();
        $dataactivelawyer = $lawyer->loadLawyerByLawStatus(2);
        $this->view->dataactivelawyer = $dataactivelawyer;
     }


     public function dielawyerAction(){
        $this->_helper->layout('layout')->disableLayout();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $lawyer = new Default_Model_Lawyer();
        $data = $lawyer->loadLawyerByLawStatus(2);
            //Khởi tạo đối tượng
        $excel = new Default_Model_Excel();
            //Chọn trang cần ghi (là số từ 0->n)
        $excel->setActiveSheetIndex(0);
            //Tạo tiêu đề cho trang. (có thể không cần)
        $excel->getActiveSheet()->setTitle('Luật sư đã chết');

            //Xét chiều rộng cho từng, nếu muốn set height thì dùng setRowHeight()
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);

            //Xét in đậm cho khoảng cột
        $excel->getActiveSheet()->getStyle('A1:I1')->getFont()->setBold(true);
        
        //Tạo tiêu đề cho từng cột
        //Vị trí có dạng như sau:
        /**
         * |A1|B1|C1|..|n1|
         * |A2|B2|C2|..|n1|
         * |..|..|..|..|..|
         * |An|Bn|Cn|..|nn|
         */
        $excel->getActiveSheet()->setCellValue('A1', 'Tên');
        $excel->getActiveSheet()->setCellValue('B1', 'Giới Tính');
        $excel->getActiveSheet()->setCellValue('C1', 'CMND');
        $excel->getActiveSheet()->setCellValue('D1', 'Số Điện Thoại');
        $excel->getActiveSheet()->setCellValue('E1', 'Mã số luật sư');
        $excel->getActiveSheet()->setCellValue('F1', 'Số chứng chỉ hành nghề');
        $excel->getActiveSheet()->setCellValue('G1', 'Tổ chức hành nghề');
        $excel->getActiveSheet()->setCellValue('H1', 'Loại luật sư');
        $excel->getActiveSheet()->setCellValue('I1', 'Tình trạng luật sư');

        

        // thực hiện thêm dữ liệu vào từng ô bằng vòng lặp
        // dòng bắt đầu = 2
        $numRow = 2;
        foreach($data as $row){
            $excel->getActiveSheet()->setCellValue('A'.$numRow, $row['cus_firstname'].' '.$row['cus_lastname']);
            if($row['cus_sex'] == 'nam'){
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nam');    
            }else{
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nữ');    
            }
                
            $excel->getActiveSheet()->setCellValue('C'.$numRow, $row['cus_identity_card']);
            $excel->getActiveSheet()->setCellValue('D'.$numRow, $row['cus_cellphone']);
            $excel->getActiveSheet()->setCellValue('E'.$numRow, $row['law_code']);
            $excel->getActiveSheet()->setCellValue('F'.$numRow, $row['law_certfication_no']);
            $excel->getActiveSheet()->setCellValue('G'.$numRow, $row['organ_name']);
            $excel->getActiveSheet()->setCellValue('H'.$numRow, $row['law_type']);
            $excel->getActiveSheet()->setCellValue('I'.$numRow, 'Đã chết');
            $numRow++;
        }
        // Khởi tạo đối tượng PHPExcel_IOFactory để thực hiện ghi file
        // ở đây mình lưu file dưới dạng excel2007 và cho người dùng download luôn
        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="DS_LuatSu_DaChet.xlsx"');
        PHPExcel_IOFactory::createWriter($excel, 'Excel2007')->save('php://output');
        return;   
     }

     public function disciplineAction(){

     }


     public function listintershipAction(){
        $intership = new Default_Model_Intership();
        $data = $intership->loadIntership();
        $this->view->data = $data;
     }
     

     public function intershipAction(){
        $this->_helper->layout('layout')->disableLayout();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $intership = new Default_Model_Intership();
        $data = $intership->loadIntership();
            //Khởi tạo đối tượng
        $excel = new Default_Model_Excel();
            //Chọn trang cần ghi (là số từ 0->n)
        $excel->setActiveSheetIndex(0);
            //Tạo tiêu đề cho trang. (có thể không cần)
        $excel->getActiveSheet()->setTitle('Luật sư tập sự');

            //Xét chiều rộng cho từng, nếu muốn set height thì dùng setRowHeight()
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);

            //Xét in đậm cho khoảng cột
        $excel->getActiveSheet()->getStyle('A1:E1')->getFont()->setBold(true);
        
        //Tạo tiêu đề cho từng cột
        //Vị trí có dạng như sau:
        /**
         * |A1|B1|C1|..|n1|
         * |A2|B2|C2|..|n1|
         * |..|..|..|..|..|
         * |An|Bn|Cn|..|nn|
         */
        $excel->getActiveSheet()->setCellValue('A1', 'Tên');
        $excel->getActiveSheet()->setCellValue('B1', 'Giới Tính');
        $excel->getActiveSheet()->setCellValue('C1', 'CMND');
        $excel->getActiveSheet()->setCellValue('D1', 'Số Điện Thoại');
        $excel->getActiveSheet()->setCellValue('E1', 'Đợt tập sự');
        

        

        // thực hiện thêm dữ liệu vào từng ô bằng vòng lặp
        // dòng bắt đầu = 2
        $numRow = 2;
        foreach($data as $row){
            $excel->getActiveSheet()->setCellValue('A'.$numRow, $row['cus_firstname'].' '.$row['cus_lastname']);
            if($row['cus_sex'] == 'nam'){
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nam');    
            }else{
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nữ');    
            }
                
            $excel->getActiveSheet()->setCellValue('C'.$numRow, $row['cus_identity_card']);
            $excel->getActiveSheet()->setCellValue('D'.$numRow, $row['cus_cellphone']);
            $excel->getActiveSheet()->setCellValue('E'.$numRow, $row['intership_number_name']);

            $numRow++;
        }
        // Khởi tạo đối tượng PHPExcel_IOFactory để thực hiện ghi file
        // ở đây mình lưu file dưới dạng excel2007 và cho người dùng download luôn
        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="DS_LuatSu_TapSu.xlsx"');
        PHPExcel_IOFactory::createWriter($excel, 'Excel2007')->save('php://output');
        return;   
     }

     public function listnotchecklawyerAction(){
        $lawyer = new Default_Model_Lawyer();
        $data = $lawyer->loadLawyerByLawStatus(6);
        $this->view->dataactivelawyer = $data;
     }

     public function notchecklawyerAction(){
        $this->_helper->layout('layout')->disableLayout();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $lawyer = new Default_Model_Lawyer();
        $data = $lawyer->loadLawyerByLawStatus(6);
            //Khởi tạo đối tượng
        $excel = new Default_Model_Excel();
            //Chọn trang cần ghi (là số từ 0->n)
        $excel->setActiveSheetIndex(0);
            //Tạo tiêu đề cho trang. (có thể không cần)
        $excel->getActiveSheet()->setTitle('Luật sư không xét');

            //Xét chiều rộng cho từng, nếu muốn set height thì dùng setRowHeight()
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);

            //Xét in đậm cho khoảng cột
        $excel->getActiveSheet()->getStyle('A1:I1')->getFont()->setBold(true);
        
        //Tạo tiêu đề cho từng cột
        //Vị trí có dạng như sau:
        /**
         * |A1|B1|C1|..|n1|
         * |A2|B2|C2|..|n1|
         * |..|..|..|..|..|
         * |An|Bn|Cn|..|nn|
         */
        $excel->getActiveSheet()->setCellValue('A1', 'Tên');
        $excel->getActiveSheet()->setCellValue('B1', 'Giới Tính');
        $excel->getActiveSheet()->setCellValue('C1', 'CMND');
        $excel->getActiveSheet()->setCellValue('D1', 'Số Điện Thoại');
        $excel->getActiveSheet()->setCellValue('E1', 'Mã số luật sư');
        $excel->getActiveSheet()->setCellValue('F1', 'Số chứng chỉ hành nghề');
        $excel->getActiveSheet()->setCellValue('G1', 'Tổ chức hành nghề');
        $excel->getActiveSheet()->setCellValue('H1', 'Loại luật sư');
        $excel->getActiveSheet()->setCellValue('I1', 'Tình trạng luật sư');

        

        // thực hiện thêm dữ liệu vào từng ô bằng vòng lặp
        // dòng bắt đầu = 2
        $numRow = 2;
        foreach($data as $row){
            $excel->getActiveSheet()->setCellValue('A'.$numRow, $row['cus_firstname'].' '.$row['cus_lastname']);
            if($row['cus_sex'] == 'nam'){
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nam');    
            }else{
                $excel->getActiveSheet()->setCellValue('B'.$numRow, 'Nữ');    
            }
                
            $excel->getActiveSheet()->setCellValue('C'.$numRow, $row['cus_identity_card']);
            $excel->getActiveSheet()->setCellValue('D'.$numRow, $row['cus_cellphone']);
            $excel->getActiveSheet()->setCellValue('E'.$numRow, $row['law_code']);
            $excel->getActiveSheet()->setCellValue('F'.$numRow, $row['law_certfication_no']);
            $excel->getActiveSheet()->setCellValue('G'.$numRow, $row['organ_name']);
            $excel->getActiveSheet()->setCellValue('H'.$numRow, $row['law_type']);
            $excel->getActiveSheet()->setCellValue('I'.$numRow, 'Không xét');
            $numRow++;
        }
        // Khởi tạo đối tượng PHPExcel_IOFactory để thực hiện ghi file
        // ở đây mình lưu file dưới dạng excel2007 và cho người dùng download luôn
        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="DS_LuatSu_KhongXet.xlsx"');
        PHPExcel_IOFactory::createWriter($excel, 'Excel2007')->save('php://output');
        return;   
     }

     public function exportallAction() {
        // $this->_helper->layout('layout')->disableLayout();
        // date_default_timezone_set('Asia/Ho_Chi_Minh');
        // $data = [
        // ['Nguyễn Khánh Linh', 'Nữ', '500k'], 
        // ['Ngọc Trinh', 'Nữ', '700k'], 
        // ['Tùng Sơn', 'Không xác định', 'Miễn phí'], 
        // ['Kenny Sang', 'Không xác định', 'Miễn phí']
        // ];
        //     //Khởi tạo đối tượng
        // $excel = new Default_Model_Excel();
        //     //Chọn trang cần ghi (là số từ 0->n)
        // $excel->setActiveSheetIndex(0);
        //     //Tạo tiêu đề cho trang. (có thể không cần)
        // $excel->getActiveSheet()->setTitle('demo ghi dữ liệu');

        //     //Xét chiều rộng cho từng, nếu muốn set height thì dùng setRowHeight()
        // $excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        // $excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        // $excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);

        //     //Xét in đậm cho khoảng cột
        // $excel->getActiveSheet()->getStyle('A1:C1')->getFont()->setBold(true);
        // //Tạo tiêu đề cho từng cột
        // //Vị trí có dạng như sau:
        // /**
        //  * |A1|B1|C1|..|n1|
        //  * |A2|B2|C2|..|n1|
        //  * |..|..|..|..|..|
        //  * |An|Bn|Cn|..|nn|
        //  */
        // $excel->getActiveSheet()->setCellValue('A1', 'Tên');
        // $excel->getActiveSheet()->setCellValue('B1', 'Giới Tính');
        // $excel->getActiveSheet()->setCellValue('C1', 'Đơn giá(/shoot)');
        // // thực hiện thêm dữ liệu vào từng ô bằng vòng lặp
        // // dòng bắt đầu = 2
        // $numRow = 2;
        // foreach($data as $row){
        //     $excel->getActiveSheet()->setCellValue('A'.$numRow, $row[0]);
        //     $excel->getActiveSheet()->setCellValue('B'.$numRow, $row[1]);
        //     $excel->getActiveSheet()->setCellValue('C'.$numRow, $row[2]);
        //     $numRow++;
        // }
        // // Khởi tạo đối tượng PHPExcel_IOFactory để thực hiện ghi file
        // // ở đây mình lưu file dưới dạng excel2007 và cho người dùng download luôn
        // header('Content-type: application/vnd.ms-excel');
        // header('Content-Disposition: attachment; filename="data.xlsx"');
        // PHPExcel_IOFactory::createWriter($excel, 'Excel2007')->save('php://output');
        // return;
	
	}
}
