<?php
// Fee controller 
class TrainingManagementController extends Zend_Controller_Action
{
    public function init(){
        $this->view->BaseUrl=$this->_request->getBaseUrl();
    }

    public function  preDispatch(){
 	
        $this->auth = Zend_Auth::getInstance();
        $this->identity = $this->auth->getIdentity();
 
        $username= $this->identity->user_username;
        $password= $this->identity->user_password;
 
        $users2 = new Default_Model_UserAdmin();  
        if ($users2->num($username, $password)>0) {                     
        
        }else{
              $this->_redirect('/default/login');exit;
        }
    }

    public function indexAction(){
        //$this->_helper->layout('homelayout')->disableLayout();
        $categoryfreetraining = new Default_Model_CategoryFeeTraining();         
        $data = $categoryfreetraining->loadCategoryFeeTraining();
        $this->view->categoryfeetraining =  $data;

        $categorytraining = new Default_Model_CategoryTraining();         
        $data = $categorytraining->loadCategoryTrainingActive();
        $this->view->categoriestrainings =  $data;
    }


    public function listAction(){
        $paymenttrainingoffline = new Default_Model_PaymentTrainingOffline();   
        $data = $paymenttrainingoffline->loadPaymentLawyerOffline();
        $this->view->paymentofflines =  $data; 
    }

    /*load history fee training by customer id*/
    public function listtrainingAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $paymentoffline = new Default_Model_PaymentTrainingOffline();   
        $cus_id = $this->getRequest()->getParam('cus_id');
        $data = $paymentoffline->loadPaymentTrainingOfflineByCusId($cus_id);
        $this->view->paymentofflines =  $data; 
    }


    public function certificationAction(){
        $paymenttrainingoffline = new Default_Model_PaymentTrainingOffline();   
        $data = $paymenttrainingoffline->loadPaymentLawyerOfflineToCreateCertification();
        $this->view->paymentofflines =  $data; 
    }

    public function detailAction(){   
        $this->_helper->layout('homelayout')->disableLayout();
        $paymenttrainingoffline = new Default_Model_PaymentTrainingOffline();   
        $paymenttraining_id = $this->getRequest()->getParam('payment_training_off_id');
        $data = $paymenttrainingoffline->loadPaymentTrainingOfflineById($paymenttraining_id);
        $this->view->paymenttraningofflinedata =  $data; 
    }

      /*update information of customer*/
    public function updateAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {

                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if($this->view->parError == ''){ 
                    $payment = new Default_Model_PaymentTrainingOffline();
                    $data = array(                 
                        'payment_training_off_status'=> $filter->filter($arrInput['payment_training_off_status'])                      
                    );
                    //$this->view->data = $data;
                    $payment->update($data, 'payment_training_off_id = '. (int)($filter->filter($arrInput['payment_training_off_id'])));                   
                }        
            }
        }    

    }


    public function createAction(){
        $this->_helper->layout('layout')->disableLayout();

        $filter = new Zend_Filter();
        if ($this->getRequest()->isXmlHttpRequest()) {
            if ($this->getRequest()->isPost()) {
                //$request = $this->getRequest();
                $arrInput = $this->_request->getParams();
                $this->view->arrInput = $arrInput;

                if(!Zend_Validate::is($arrInput['cus_id'],'NotEmpty')){
                    $this->view->parError = 'Bạn phải chọn luật sư để tạo phí thành viên!';
                }
    
                if(!Zend_Validate::is($arrInput['category_training_id'],'NotEmpty')){
                    $this->view->parError = 'Bạn phải chọn khóa đào tạo';
                }

                if(!Zend_Validate::is($arrInput['category_fee_training_id'],'NotEmpty')){
                    $this->view->parError = 'Bạn phải chọn phí đào tạo';
                }                
                 
               if($this->view->parError == ''){
                    $date = new Zend_Date();
                    $billoffline = new Default_Model_BillTrainingOffline();
                                    
                    $data = array(              
                        'category_fee_training_id' => $filter->filter($arrInput['category_fee_training_id']),
                        'category_training_id' => $filter->filter($arrInput['category_training_id']),
                        'cus_id' => $filter->filter($arrInput['cus_id'])
                     );

                    $billoffline_id = $billoffline->insert($data);

                    $paymenttraining = new Default_Model_PaymentTrainingOffline();                  
                    
                    $data_paymenttraining = array(
                        'payment_training_off_code' => $paymenttraining->generationCode('BDĐT','OFFLINE'),
                        'bill_trainingoffline_id' => $billoffline_id,
                        'payment_training_off_status' => '0',
                        'payment_training_off_created_date' => $date->toString('YYYY-MM-dd HH:mm:ss'),
                        'amount' =>  $filter->filter($arrInput['amount'])

                    );
                    $paymenttraining ->insert($data_paymenttraining);  
                                      
                 }                   
             }
         }    
    }

    public function printtrainingpaymentAction(){
        $this->_helper->layout('homelayout')->disableLayout();
        $paymentlawyertrainingoffline = new Default_Model_PaymentTrainingOffline();   
        $payment_training_off_id = $this->getRequest()->getParam('payment_training_off_id');
        $data = $paymentlawyertrainingoffline->loadPaymentTrainingOfflineById($payment_training_off_id);
        $this->view->paymentlawyertrainingofflinedata =  $data; 
    }

}