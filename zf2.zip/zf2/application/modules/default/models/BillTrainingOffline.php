<?php

class Default_Model_BillTrainingOffline  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'bill_training_offline';

    protected $_primary = 'bill_trainingoffline_id'; 

    protected $_sequence = true;

}