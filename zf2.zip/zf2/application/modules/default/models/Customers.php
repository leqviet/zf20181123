<?php

class Default_Model_Customers  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'customers';

    protected $_primary = 'cus_id'; 

    protected $_sequence = true;


    /*load customers*/
    public function loadCustomers()
    {
        $select = $this->select()
                       ->from($this,array('cus_birthday','cus_identity_place','cus_identity_card','cus_sex','cus_id','cus_firstname','cus_lastname','cus_cellphone'));
                       //->where('city_active = ?', '1');
                        
        $row = $this->fetchAll($select);
        return $row;
    }

    /*get customer by phone*/
    public function getCustomer($phone_number)
    {
        $phone_number = (int)$phone_number;
        $row = $this->fetchRow('cus_cellphone = ' . $phone_number);
        if (!$row) {
            return null;
        }
        return $row->toArray();
    }

    /*searchu customer by id or name */
    public function searchByCellPhoneOrIdentityCardOrName($q)
    {
        $select = $this->select()
                       ->from($this)
                       ->where('cus_cellphone LIKE ?', '%' . $q . '%')
                       ->orWhere('cus_identity_card LIKE ?', '%' . $q . '%')
                       ->orWhere('cus_fullname LIKE ?','%' . $q .'%');
                       //->orWhere('cus_ > ?', $maximumPrice);
    
        $row = $this->fetchAll($select);
         return $row;
    }

    /*update customer by cus_cellphone*/
    public function updateCustomer($cus_cellphone,$cus_firstname)
    {
        $data = array(
            // 'payment' => $payment,
            // 'pass' => $pass,
            'cus_firstname'=> $cus_firstname
        );
        $this->update($data, 'cus_cellphone = '. (int)$cus_cellphone);
    }

    // public function createCustomer($cus_firstname,$cus_lastname,$cus_sex){
    //     $data = array(
    //         'cus_firstname' => $cus_firstname,
    //         'cus_lastname' => $cus_lastname,
    //         'cus_sex' => $cus_sex,
    //         'cus_country' => $cus_country,
    //         'cus_birthday' => $cus_birthday,
    //         'cus_nation' => $cus_nation,
    //         'cus_birthplace' => $cus_birthplace,
    //         'cus_cellphone' => $cus_cellphone
    //         ,'cus_homephone' => $cus_homephone
    //         ,'cus_identity_card' => $cus_identity_card
    //         ,'cus_identity_place' => $cus_identity_place
    //         ,'cus_identity_date' => $cus_identity_date
    //         ,'cus_passport_card' => $cus_passport_card
    //         ,'cus_passport_place' => $cus_passport_place
    //         ,'cus_passport_date' => $cus_passport_date
    //         ,'cus_address_resident' => $cus_address_resident
    //         ,'cus_educations' => $cus_educations
    //         ,'cus_member' => $cus_member
    //         ,'cus_language_level' => $cus_language_level
    //         ,'cus_users_created' => $cus_users_created
    //         // ,'cus_date_created' => $cus_date_created
    //         // ,'cus_users_update'=>
    //         // ,'cus_date_update' =>
    //         ,'cus_status' => $cus_status
    //         ,'cus_active' => $cus_active
    //         ,'city_id' => $city_id
    //         // ,'user_id' => create by
    //         ,'cus_fullname' => $cus_fullname            
    //         ,'cus_username' => $cus_username
    //         ,'cus_password' => $cus_password    
    //     );

    //     $this->insert($data);
    // }

    public function validateUsernameCustomer($type,$data){
    
        // $select = $this->select()
        // ->from($this)
        // ->where('cus_username = ?', $q);
        // //->orWhere('cus_identity_card LIKE ?', '%' . $q . '%');
        // //->orWhere('cus_ > ?', $maximumPrice);

        $checkquery = $this->select()
        ->from($this, array("num"=>"COUNT(*)"))
        ->where("cus_username = ?", $data);
       

        $checkrequest = $this->fetchRow($checkquery);
        // echo $checkrequest["num"];

        // $row = $this->fetchRow($select);
        return $checkrequest["num"];

    }



    /* validate data customer*/
    public function validateCustomer($type,$data){
        //validate phone number
        $row = null;
        if($type == "phone"){
            $row = $this->fetchRow('cus_cellphone = ' . $data);
        }else if($type == "cardnumber"){
            $row = $this->fetchRow('cus_identity_card = ' . $data);    
        }else if($type == "username"){
            $row = $this->fetchRow('cus_username = ' . $data);     
        }        

        // echo $row->toArray();

        if (!$row) {
            return null;
        }  

        return $row->toArray();
    }

}    