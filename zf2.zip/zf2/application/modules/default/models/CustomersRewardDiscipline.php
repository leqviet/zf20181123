<?php

class Default_Model_CustomersRewardDiscipline  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'customers_reward_discipline';

    protected $_primary = 'id'; 

    protected $_sequence = true;


     /*load oayment joining ofiline by cus id*/
     public function loadCustomersRewardByCusId($cus_id)
     {
         $db = Zend_Db_Table::getDefaultAdapter();
         $select = new Zend_Db_Select($db);
         $select->distinct()
             ->from('customers_reward_discipline', array('id'
             ,'cus_id'
             ,'reward_date'
             ,'reward_reason'
             ,'discipline_date'
             ,'discipline_reason',
             'createdate'))
             ->joinInner(
                 'customers',
                 'customers.cus_id = customers_reward_discipline.cus_id',
                 array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))   
            
             ->where('customers.cus_id = ?',$cus_id)
             ->order('customers_reward_discipline.createdate');
                         
         $row = $db->fetchAll($select);
         return $row;
     }
 

    
}