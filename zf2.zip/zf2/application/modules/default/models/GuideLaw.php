<?php

class Default_Model_GuideLaw  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'guide_law';

    //protected $_primary = 'users_id'; 

}    