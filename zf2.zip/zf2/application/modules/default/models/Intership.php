<?php

class Default_Model_Intership  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'intership';

    protected $_primary = 'inter_id'; 

    protected $_sequence = true;

    public function generationCode($paymentType,$paymentOption){
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $currentdate = new Zend_Date();
        $monthYear = $currentdate->toString('MMYYYY');
        $checkquery = $db->select()
        ->from("intership", array('inter_id'))
        ->order('inter_id desc')
        ->limit(1);

        $checkrequest = $db->fetchRow($checkquery);      

        //$text = '0001'.'_'.$monthYear.'_'.'PTV'.'_'.'ONLINE';

        $text = '';
        if(strlen($checkrequest["inter_id"]) > 0){
            $id = $checkrequest["inter_id"] + 1;
            $lengthid = strlen($id);
            if($lengthid == 1){
                $text = '000'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }else if($lengthid == 2){
                $text = '00'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;    
            }else if($lengthid == 3){
                $text = '0'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }else if($lengthid == 4){
                $text = $id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }           
        }else{
            $text = '0001'.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
        }
        return $text;
    }

    //function to check course expirse date before creating new intership for customers
    public function checkBeforeCreateIntership($cus_id){
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()->from('intership', array('inter_id','cus_id'))
       ->joinInner(
           'intership_number',
           'intership_number.intership_number_id = intership.intership_number_id',
           array('intership_number_enddate'))   
       ->where('intership.cus_id = ?',$cus_id)
       ->order('intership.inter_created_date desc');
       //->limit(1);
    
        $resultSet = $db->fetchRow($select); 
     
        if(strtotime($resultSet['intership_number_enddate']) + 60 < time()) {
            return null;
        }
        return $resultSet;
    }

    public function listIntership($cus_username)
    {
        $select = $this->select();
        $adapter = new Zend_Paginator_Adapter_DbTableSelect($select);
        return $adapter;

    }

    public function loadIntershipByInterId($inter_id){
        $row = $this->fetchRow('inter_id = ' .(int) $inter_id);
        if (!$row) {
            return null;
        }
        return $row->toArray();
    }

    public function loadIntershipByCusId($cus_id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
                       ->from('intership',array('inter_id','inter_code','inter_regis_date','inter_created_date','cus_id','lawnum_id','intership_number_id'))
                       ->joinInner(
                        'intership_number',
                        'intership_number.intership_number_id = intership.intership_number_id',
                        array('intership_number_name'=>'intership_number_name')) 
                        ->joinLeft(
                            'guide_law',
                            'guide_law.inter_id = intership.inter_id',
                        array('law_id'=>'law_id')) 
                        // ->joinLeft(
                        //     'lawyer',
                        //     'lawyer.law_id = guide_law.law_id',
                        // array())     
                       ->where('cus_id = ?', $cus_id);       
                        
        $row = $db->fetchAll($select);
        return $row;
    }    

    public function loadIntership()
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
                       ->from('intership',array('inter_id','inter_code','inter_regis_date','inter_created_date','cus_id','lawnum_id','intership_number_id'))
                       ->joinInner(
                        'intership_number',
                        'intership_number.intership_number_id = intership.intership_number_id',
                        array('intership_number_name'=>'intership_number_name')) 
                        ->joinLeft(
                            'guide_law',
                            'guide_law.inter_id = intership.inter_id',
                        array('law_id'=>'law_id')) 
                        ->joinLeft(
                            'customers',
                            'customers.cus_id = intership.cus_id',
                            array('cus_firstname'=>'cus_firstname', 'cus_lastname'=>'cus_lastname'
                            ,'cus_cellphone'=>'cus_cellphone',
                            'cus_sex'=>'cus_sex' ,'cus_identity_card'=>'cus_identity_card'));  
                       //->where('cus_id = ?', $cus_id);       
                        
        $row = $db->fetchAll($select);
        return $row;
    }    

}    