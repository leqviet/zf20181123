<?php

class Default_Model_Lawyer  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'lawyer';

    protected $_primary = 'law_id'; 

    protected $_sequence = true;

    public function loadLawyer(){
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
                       ->from('lawyer',array('law_id','law_certfication_no',
                       'cus_id','organ_lid','act_id',
                       'lawstatus_id','certification_id','organization_law.organ_name'))
                       ->joinLeft(
                        'customers',
                        'customers.cus_id = lawyer.cus_id',
                        array('cus_firstname'=>'cus_firstname', 
                        'cus_lastname'=>'cus_lastname','cus_cellphone'=>'cus_cellphone')) 
                        ->joinLeft(
                        'organization_law',
                        'organization_law.organ_lid = lawyer.organ_lid',
                        array('organ_name'=>'organ_name')) 
                        ->joinLeft(
                        'activity_law',
                        'activity_law.act_id = lawyer.act_id',
                        array('act_name'=>'act_name'))
                        ->joinLeft(
                            'law_status',
                            'law_status.lawstatus_id = lawyer.lawstatus_id',
                            array('lawstatus_name'=>'lawstatus_name'));
                        // ->joinLeft(
                        //     'certification',
                        //     'certification.certification_id = lawyer.certification_id',
                        //     array('number'=>'cer_number'))
                       //->where('lawyer.cus_id = ?',$cus_id);
                    //    ->group('lawyer.law_id')
                    //    ->group('lawyer.law_certfication_no');
                        
        $row = $db->fetchAll($select);
        return $row;

    }

    public function loadLawyerByLawStatus($idstatus){
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
                       ->from('lawyer',array('law_id','law_certfication_no',
                       'cus_id','organ_lid','act_id','law_type','law_code',
                       'lawstatus_id','certification_id','organization_law.organ_name'))
                       ->joinLeft(
                        'customers',
                        'customers.cus_id = lawyer.cus_id',
                        array('cus_sex'=>'cus_sex' ,'cus_firstname'=>'cus_firstname',
                         'cus_lastname'=>'cus_lastname',
                         'cus_cellphone'=>'cus_cellphone',
                         'cus_identity_card'=>'cus_identity_card')) 
                        ->joinLeft(
                        'organization_law',
                        'organization_law.organ_lid = lawyer.organ_lid',
                        array('organ_name'=>'organ_name')) 
                        ->joinLeft(
                        'activity_law',
                        'activity_law.act_id = lawyer.act_id',
                        array('act_name'=>'act_name'))
                        ->joinLeft(
                            'law_status',
                            'law_status.lawstatus_id = lawyer.lawstatus_id',
                            array('lawstatus_name'=>'lawstatus_name'))
                        // ->joinLeft(
                        //     'certification',
                        //     'certification.certification_id = lawyer.certification_id',
                        //     array('number'=>'cer_number'))
                       //->where('lawyer.cus_id = ?',$cus_id);
                    //    ->group('lawyer.law_id')
                    //    ->group('lawyer.law_certfication_no');
                    ->where('law_status.lawstatus_id = ?',$idstatus);
                        
        $row = $db->fetchAll($select);
        return $row;

    }

    
    public function loadLawyerActive(){
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
                       ->from('lawyer',array('law_id','law_certfication_no',
                       'cus_id','organ_lid','act_id','law_type','law_code',
                       'lawstatus_id','certification_id','organization_law.organ_name'))
                       ->joinLeft(
                        'customers',
                        'customers.cus_id = lawyer.cus_id',
                        array('cus_firstname'=>'cus_firstname',
                        'cus_lastname'=>'cus_lastname',
                        'cus_cellphone'=>'cus_cellphone',
                        'cus_sex'=>'cus_sex',
                        'cus_identity_card'=>'cus_identity_card')) 
                        ->joinLeft(
                        'organization_law',
                        'organization_law.organ_lid = lawyer.organ_lid',
                        array('organ_name'=>'organ_name')) 
                        ->joinLeft(
                        'activity_law',
                        'activity_law.act_id = lawyer.act_id',
                        array('act_name'=>'act_name'))
                        ->joinLeft(
                            'law_status',
                            'law_status.lawstatus_id = lawyer.lawstatus_id',
                            array('lawstatus_name'=>'lawstatus_name'));
                        // ->joinLeft(
                        //     'certification',
                        //     'certification.certification_id = lawyer.certification_id',
                        //     array('number'=>'cer_number'))
                       //->where('lawyer.cus_id = ?',$cus_id);
                    //    ->group('lawyer.law_id')
                    //    ->group('lawyer.law_certfication_no');
                        
        $row = $db->fetchAll($select);
        return $row;

    }

    public function loadLawyerByLawId($law_id){
        $row = $this->fetchRow('law_id = ' .(int) $law_id);
        if (!$row) {
            return null;
        }
        return $row->toArray();
    }

    public function loadLawyerByCusId($cus_id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
                       ->from('lawyer',array('law_joining_number','law_organ_old','law_type','law_id','law_certfication_no',
                       'cus_id','organ_lid','act_id',
                       'lawstatus_id','certification_id','organization_law.organ_name'))
                       ->joinLeft(
                        'customers',
                        'customers.cus_id = lawyer.cus_id',
                        array()) 
                        ->joinLeft(
                        'organization_law',
                        'organization_law.organ_lid = lawyer.organ_lid',
                        array('organ_name'=>'organ_name')) 
                        ->joinLeft(
                        'activity_law',
                        'activity_law.act_id = lawyer.act_id',
                        array('act_name'=>'act_name'))
                        ->joinLeft(
                            'law_status',
                            'law_status.lawstatus_id = lawyer.lawstatus_id',
                            array('lawstatus_name'=>'lawstatus_name'))
                        // ->joinLeft(
                        //     'certification',
                        //     'certification.certification_id = lawyer.certification_id',
                        //     array('number'=>'cer_number'))
                       ->where('lawyer.cus_id = ?',$cus_id);
                    //    ->group('lawyer.law_id')
                    //    ->group('lawyer.law_certfication_no');
                        
        $row = $db->fetchAll($select);
        return $row;
    }
}