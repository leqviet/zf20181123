<?php

class Default_Model_LawyerNumber  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'lawyer_number';

    protected $_primary = 'lawnum_id'; 

    protected $_sequence = true;

  

}