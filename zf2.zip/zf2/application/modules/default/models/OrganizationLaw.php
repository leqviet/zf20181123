<?php

class Default_Model_OrganizationLaw  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'organization_law';

    protected $_primary = 'organ_lid'; 

    protected $_sequence = true;

    public function loadOrganzationLaw()
    {
        $select = $this->select()
                       ->from($this,array('organ_lid','organ_name'));        
                        
        $row = $this->fetchAll($select);
        return $row;
    }

}