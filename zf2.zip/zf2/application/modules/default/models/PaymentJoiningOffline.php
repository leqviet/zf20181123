<?php

class Default_Model_PaymentJoiningOffline  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'payment_joining_offline';

    protected $_primary = 'payment_joining_off_id'; 

    protected $_sequence = true;

    public function generationCode($paymentType,$paymentOption){
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $currentdate = new Zend_Date();
        $monthYear = $currentdate->toString('MMYYYY');
        $checkquery = $db->select()
        ->from("payment_joining_offline", array('payment_joining_off_id'))
        ->order('payment_joining_off_id desc')
        ->limit(1);

        $checkrequest = $db->fetchRow($checkquery);      

        $text = '';
        $length = strlen($checkrequest["payment_joining_off_id"]);
        if($length > 0){
            $id = $checkrequest["payment_joining_off_id"] + 1;
            $lengthid = strlen($id);
            if($lengthid == 1){
                $text = '000'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }else if($lengthid == 2){
                $text = '00'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;    
            }else if($lengthid == 3){
                $text = '0'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }else if($lengthid == 4){
                $text = $id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }           
        }else{
            $text = '0001'.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
        }
        return $text;
    }



    /*load oayment joining ofiline by cus id*/
    public function loadPaymentJoiningOfflineByCusId($cus_id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
            ->from('payment_joining_offline', array('payment_joining_off_id'
            ,'payment_joining_off_code'
            ,'payment_joining_off_created_date'
            ,'payment_joining_off_status'
            ,'payment_joining_off_updatedate'
            ,'bill_feeoffline_id'
            ,'amount'))
            ->joinInner(
            'bill_fee_offline',
            'bill_fee_offline.bill_feeoffline_id = payment_joining_offline.bill_feeoffline_id',
            array()) 
            ->joinInner(
            'lawyer_number',
            'lawyer_number.lawnum_id = bill_fee_offline.lawnum_id',
            array('month'=>'month')) 
            ->joinInner(
            'category_fee_lawyer',
            'category_fee_lawyer.category_fee_lawyer_id = lawyer_number.category_fee_lawyer_id',
            array('name'=>'name','mooney'=>'mooney'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_fee_offline.cus_id',
                array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))   
           
            ->where('customers.cus_id = ?',$cus_id)
            ->order('payment_joining_offline.payment_joining_off_created_date');
                        
        $row = $db->fetchAll($select);
        return $row;
    }

    public function loadPaymentJoiningOfflineById($id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        // $select = new Zend_Db_Select($db);
        $query = $db->select()
            ->from("payment_joining_offline", array('payment_joining_off_id'
            ,'payment_joining_off_code'
            ,'payment_joining_off_created_date'
            ,'payment_joining_off_status'
            ,'payment_joining_off_updatedate'
            ,'bill_feeoffline_id'
            ,'amount'))
            ->joinInner(
            'bill_fee_offline',
            'bill_fee_offline.bill_feeoffline_id = payment_joining_offline.bill_feeoffline_id',
            array())         
            ->joinInner(
            'lawyer_number',
            'lawyer_number.lawnum_id = bill_fee_offline.lawnum_id',
            array('month'=>'month')) 
            ->joinInner(
            'category_fee_lawyer',
            'category_fee_lawyer.category_fee_lawyer_id = lawyer_number.category_fee_lawyer_id',
            array('name'=>'name','mooney'=>'mooney'))
            // ->joinInner(
            //     'course',
            //     'course.course_id = bill_training_offline.course_id',
            //     array('course_name'=>'course_name'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_fee_offline.cus_id',
                array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname','cus_birthday'=>'cus_birthday'))   
            ->where('payment_joining_offline.payment_joining_off_id = ?',$id)
            ->limit(1);   
                        
        return $db->fetchRow($query);
    }
    

    public function loadPaymentJoiningOffline()
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
            ->from('payment_joining_offline', array('payment_joining_off_id'
            ,'payment_joining_off_code'
            ,'payment_joining_off_created_date'
            ,'payment_joining_off_status'
            ,'payment_joining_off_updatedate'
            ,'amount'
            ,'bill_feeoffline_id'))
            ->joinInner(
            'bill_fee_offline',
            'bill_fee_offline.bill_feeoffline_id = payment_joining_offline.bill_feeoffline_id',
            array()) 
            ->joinInner(
            'lawyer_number',
            'lawyer_number.lawnum_id = bill_fee_offline.lawnum_id',
            array('month'=>'month')) 
            ->joinInner(
            'category_fee_lawyer',
            'category_fee_lawyer.category_fee_lawyer_id = lawyer_number.category_fee_lawyer_id',
            array('name'=>'name','mooney'=>'mooney'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_fee_offline.cus_id',
                array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))    
            // ->joinInner(
            //     'lawyer',
            //     'lawyer.cus_id = customers.cus_id',
            //     array('law_code'=>'law_code','law_certfication_no'=>'law_certfication_no'))
            ->order('payment_joining_offline.payment_joining_off_created_date')
            ->where('payment_joining_offline.payment_joining_off_status = 0');
            //->where('customers.cus_id = ?',$cus_id);
                        
        $row = $db->fetchAll($select);
        return $row;
    }
}