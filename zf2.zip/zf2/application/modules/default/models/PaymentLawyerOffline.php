<?php

class Default_Model_PaymentLawyerOffline  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'payment_lawyer_offline';

    protected $_primary = 'payment_lawyer_off_id'; 

    protected $_sequence = true;

    
    public function generationCode($paymentType,$paymentOption){
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $currentdate = new Zend_Date();
        $monthYear = $currentdate->toString('MMYYYY');
        $checkquery = $db->select()
        ->from("payment_lawyer_offline", array('payment_lawyer_off_id'))
        ->order('payment_lawyer_off_id desc')
        ->limit(1);

        $checkrequest = $db->fetchRow($checkquery);      

        $text = '';
        $length = strlen($checkrequest["payment_lawyer_off_id"]);
        if($length > 0){
            $id = $checkrequest["payment_lawyer_off_id"] + 1;
            $lengthid = strlen($id);
            if($lengthid == 1){
                $text = '000'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }else if($lengthid == 2){
                $text = '00'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;    
            }else if($lengthid == 3){
                $text = '0'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }else if($lengthid == 4){
                $text = $id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }           
        }else{
            $text = '0001'.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
        }
        return $text;
    }


    public function loadPaymentLawyerOfflinegById($id){
        $row = $this->fetchRow('payment_lawyer_off_id = ' .(int) $id);
        if (!$row) {
            return null;
        }
        return $row->toArray();
    }

    public function loadPaymentLawyerOfflineByCusId($cus_id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
            ->from('payment_lawyer_offline', array('payment_lawyer_off_id'
            ,'payment_lawyer_off_code'
            ,'payment_lawyer_off_created_date'
            ,'payment_lawyer_off_status'
            ,'payment_lawyer_off_updatedate'
            ,'bill_feeoffline_id'))
            ->joinInner(
            'bill_fee_offline',
            'bill_fee_offline.bill_feeoffline_id = payment_lawyer_offline.bill_feeoffline_id',
            array()) 
            ->joinInner(
            'lawyer_number',
            'lawyer_number.lawnum_id = bill_fee_offline.lawnum_id',
            array('month'=>'month')) 
            ->joinInner(
            'category_fee_lawyer',
            'category_fee_lawyer.category_fee_lawyer_id = lawyer_number.category_fee_lawyer_id',
            array('name'=>'name','mooney'=>'mooney'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_fee_offline.cus_id',
                array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))    
            ->joinInner(
                'lawyer',
                'lawyer.cus_id = customers.cus_id',
                array('law_code'=>'law_code','law_certfication_no'=>'law_certfication_no'))  
            ->where('customers.cus_id = ?',$cus_id)
            ->where('category_fee_lawyer.type = ?' ,'member')
            ->order('payment_lawyer_offline.payment_lawyer_off_created_date');
                        
        $row = $db->fetchAll($select);
        return $row;
    }
    

    public function loadPaymentLawyerOffline()
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
            ->from('payment_lawyer_offline', array('payment_lawyer_off_id'
            ,'payment_lawyer_off_code'
            ,'payment_lawyer_off_created_date'
            ,'payment_lawyer_off_status'
            ,'payment_lawyer_off_updatedate'
            ,'amount'
            ,'bill_feeoffline_id'))
            ->joinInner(
            'bill_fee_offline',
            'bill_fee_offline.bill_feeoffline_id = payment_lawyer_offline.bill_feeoffline_id',
            array()) 
            ->joinInner(
            'lawyer_number',
            'lawyer_number.lawnum_id = bill_fee_offline.lawnum_id',
            array('month'=>'month')) 
            ->joinInner(
            'category_fee_lawyer',
            'category_fee_lawyer.category_fee_lawyer_id = lawyer_number.category_fee_lawyer_id',
            array('name'=>'name','mooney'=>'mooney'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_fee_offline.cus_id',
                array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))    
            ->joinInner(
                'lawyer',
                'lawyer.cus_id = customers.cus_id',
                array('law_code'=>'law_code','law_certfication_no'=>'law_certfication_no'))
            ->order('payment_lawyer_offline.payment_lawyer_off_created_date')
            ->where('payment_lawyer_offline.payment_lawyer_off_status = 0');
                        
        $row = $db->fetchAll($select);
        return $row;
    }

    public function loadPaymentLawyerOfflineById($id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        // $select = new Zend_Db_Select($db);
        $query = $db->select()
            ->from("payment_lawyer_offline", array('payment_lawyer_off_id'
            ,'payment_lawyer_off_code'
            ,'payment_lawyer_off_created_date'
            ,'payment_lawyer_off_status'
            ,'payment_lawyer_off_updatedate'
            ,'bill_feeoffline_id'
            ,'amount'))
            ->joinInner(
            'bill_fee_offline',
            'bill_fee_offline.bill_feeoffline_id = payment_lawyer_offline.bill_feeoffline_id',
            array())         
            ->joinInner(
            'lawyer_number',
            'lawyer_number.lawnum_id = bill_fee_offline.lawnum_id',
            array('month'=>'month')) 
            ->joinInner(
            'category_fee_lawyer',
            'category_fee_lawyer.category_fee_lawyer_id = lawyer_number.category_fee_lawyer_id',
            array('name'=>'name','mooney'=>'mooney'))
            // ->joinInner(
            //     'course',
            //     'course.course_id = bill_training_offline.course_id',
            //     array('course_name'=>'course_name'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_fee_offline.cus_id',
                array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname','cus_birthday'=>'cus_birthday'))   
            ->where('payment_lawyer_offline.payment_lawyer_off_id = ?',$id)
            ->limit(1);   
                        
        return $db->fetchRow($query);
        // if (!$row) {
        //     return null;
        // }
        //return $row->toArray();
    }
}