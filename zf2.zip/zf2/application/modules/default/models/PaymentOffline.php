<?php

class Default_Model_PaymentOffline  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'payment_offline';

    protected $_primary = 'payment_id'; 

    protected $_sequence = true;

    
    public function generationCode($paymentType,$paymentOption){
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $currentdate = new Zend_Date();
        $monthYear = $currentdate->toString('MMYYYY');
        $checkquery = $db->select()
        ->from("payment_offline", array('payment_id'))
        ->order('payment_id desc')
        ->limit(1);

        $checkrequest = $db->fetchRow($checkquery);      

        $text = '';
        $length = strlen($checkrequest["payment_id"]);
        if($length > 0){
            $id = $checkrequest["payment_id"] + 1;
            if($length == 1){
                $text = '000'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }else if($length == 2){
                $text = '00'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;    
            }else if($length == 3){
                $text = '0'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }else if($length == 4){
                $text = $id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }           
        }else{
            $text = '0001'.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
        }
        return $text;
    }


    // public function loadPaymentIntershipOfflineById($id)
    // {
    //     $db = Zend_Db_Table::getDefaultAdapter();
    //     // $select = new Zend_Db_Select($db);
    //     $query = $db->select()
    //         ->from("payment_intership_offline", array('payment_inter_off_id'
    //         ,'payment_inter_off_code'
    //         ,'payment_inter_off_created_date'
    //         ,'payment_inter_off_status'
    //         ,'payment_inter_off_updatedate'
    //         ,'bill_feeoffline_id'))
    //         ->joinInner(
    //         'bill_fee_offline',
    //         'bill_fee_offline.bill_feeoffline_id = payment_intership_offline.bill_feeoffline_id',
    //         array())         
    //         ->joinInner(
    //         'lawyer_number',
    //         'lawyer_number.lawnum_id = bill_fee_offline.lawnum_id',
    //         array()) 
    //         ->joinInner(
    //         'category_fee_lawyer',
    //         'category_fee_lawyer.category_fee_lawyer_id = lawyer_number.category_fee_lawyer_id',
    //         array('name'=>'name','mooney'=>'mooney'))
    //          ->joinInner(
    //             'customers',
    //             'customers.cus_id = bill_fee_offline.cus_id',
    //             array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))   
    //         ->where('payment_intership_offline.payment_inter_off_id = ?',$id)
    //         ->limit(1);   
                        
    //     return $db->fetchRow($query);
    // }

    
    // /*load oayment intership ofiline by cus id*/
    // public function loadPaymentIntershipOfflineByCusId($cus_id)
    // {
    //     $db = Zend_Db_Table::getDefaultAdapter();
    //     $select = new Zend_Db_Select($db);
    //     $select->distinct()
    //         ->from('payment_intership_offline', array('payment_inter_off_id'
    //         ,'payment_inter_off_code'
    //         ,'payment_inter_off_created_date'
    //         ,'payment_inter_off_status'
    //         ,'payment_inter_off_updatedate'
    //         ,'bill_feeoffline_id'))
    //         ->joinInner(
    //         'bill_fee_offline',
    //         'bill_fee_offline.bill_feeoffline_id = payment_intership_offline.bill_feeoffline_id',
    //         array()) 
    //         ->joinInner(
    //         'lawyer_number',
    //         'lawyer_number.lawnum_id = bill_fee_offline.lawnum_id',
    //         array('month'=>'month')) 
    //         ->joinInner(
    //         'category_fee_lawyer',
    //         'category_fee_lawyer.category_fee_lawyer_id = lawyer_number.category_fee_lawyer_id',
    //         array('name'=>'name','mooney'=>'mooney'))
    //         ->joinInner(
    //             'customers',
    //             'customers.cus_id = bill_fee_offline.cus_id',
    //             array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))   
           
    //         ->where('customers.cus_id = ?',$cus_id)
    //         ->order('payment_intership_offline.payment_inter_off_created_date');
                        
    //     $row = $db->fetchAll($select);
    //     return $row;
    // }
    

    // public function loadPaymentIntershipOffline()
    // {
    //     $db = Zend_Db_Table::getDefaultAdapter();
    //     $select = new Zend_Db_Select($db);
    //     $select->distinct()
    //         ->from('payment_intership_offline', array('payment_inter_off_id'
    //         ,'payment_inter_off_code'
    //         ,'payment_inter_off_created_date'
    //         ,'payment_inter_off_status'
    //         ,'payment_inter_off_updatedate'
    //         ,'bill_feeoffline_id'))
    //         ->joinInner(
    //         'bill_fee_offline',
    //         'bill_fee_offline.bill_feeoffline_id = payment_intership_offline.bill_feeoffline_id',
    //         array()) 
    //         ->joinInner(
    //         'lawyer_number',
    //         'lawyer_number.lawnum_id = bill_fee_offline.lawnum_id',
    //         array('month'=>'month')) 
    //         ->joinInner(
    //         'category_fee_lawyer',
    //         'category_fee_lawyer.category_fee_lawyer_id = lawyer_number.category_fee_lawyer_id',
    //         array('name'=>'name','mooney'=>'mooney'))
    //         ->joinInner(
    //             'customers',
    //             'customers.cus_id = bill_fee_offline.cus_id',
    //             array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))    
    //         // ->joinInner(
    //         //     'lawyer',
    //         //     'lawyer.cus_id = customers.cus_id',
    //         //     array('law_code'=>'law_code','law_certfication_no'=>'law_certfication_no'))
    //         ->order('payment_intership_offline.payment_inter_off_created_date')
    //         ->where('payment_intership_offline.payment_inter_off_status = 0');
    //         //->where('customers.cus_id = ?',$cus_id);
                        
    //     $row = $db->fetchAll($select);
    //     return $row;
    // }
}