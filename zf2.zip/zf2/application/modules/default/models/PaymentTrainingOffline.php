<?php

class Default_Model_PaymentTrainingOffline  extends Zend_Db_Table_Abstract{
    
    protected $_name = 'payment_training_offline';

    protected $_primary = 'payment_training_off_id'; 

    protected $_sequence = true;

    public function generationCode($paymentType,$paymentOption){
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $currentdate = new Zend_Date();
        $monthYear = $currentdate->toString('MMYYYY');
        $checkquery = $db->select()
        ->from("payment_training_offline", array('payment_training_off_id'))
        ->order('payment_training_off_id desc')
        ->limit(1);

        $checkrequest = $db->fetchRow($checkquery);      

        $text = '';
        $length = strlen($checkrequest["payment_training_off_id"]);
        if($length > 0){
            $id = $checkrequest["payment_training_off_id"] + 1;
            if($length == 1){
                $text = '000'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }else if($length == 2){
                $text = '00'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;    
            }else if($length == 3){
                $text = '0'.$id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }else if($length == 4){
                $text = $id.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
            }           
        }else{
            $text = '0001'.'_'.$monthYear.'_'.$paymentType.'_'.$paymentOption;
        }
        return $text;
    }

    public function loadPaymentLawyerOffline()
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
            ->from('payment_training_offline', array('payment_training_off_id'
            ,'payment_training_off_code'
            ,'payment_training_off_created_date'
            ,'payment_training_off_status'
            ,'payment_training_off_updatedate'
            ,'amount'
            ,'bill_trainingoffline_id'))
            ->joinInner(
            'bill_training_offline',
            'bill_training_offline.bill_trainingoffline_id = payment_training_offline.bill_trainingoffline_id',
            array())         
            ->joinInner(
            'category_fee_training',
            'category_fee_training.category_fee_training_id = bill_training_offline.category_fee_training_id',
            array('name'=>'name','mooney'=>'mooney'))
            ->joinInner(
                'category_training',
                'category_training.cat_train_id = bill_training_offline.category_training_id',
                array('cat_train_name'=>'cat_train_name','cat_train_number'=>'cat_train_number'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_training_offline.cus_id',
                array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))    
            
            ->order('payment_training_offline.payment_training_off_created_date');
            //->where('customers.cus_id = ?',$cus_id);
                        
        $row = $db->fetchAll($select);
        return $row;
    }


    public function loadPaymentLawyerOfflineToCreateCertificationByCusId($cus_id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
            ->from('payment_training_offline', array('payment_training_off_id'
            ,'payment_training_off_code'
            ,'payment_training_off_created_date'
            ,'payment_training_off_status'
            ,'payment_training_off_updatedate'
            ,'bill_trainingoffline_id'))
            ->joinInner(
            'bill_training_offline',
            'bill_training_offline.bill_trainingoffline_id = payment_training_offline.bill_trainingoffline_id',
            array())         
            ->joinInner(
            'category_fee_training',
            'category_fee_training.category_fee_training_id = bill_training_offline.category_fee_training_id',
            array('name'=>'name','mooney'=>'mooney'))
            ->joinInner(
                'category_training',
                'category_training.cat_train_id = bill_training_offline.category_training_id',
                array('cat_train_name'=>'cat_train_name','cat_train_number'=>'cat_train_number'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_training_offline.cus_id',
                array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname')) 
            ->joinInner(
                'lawyer',
                'lawyer.cus_id = customers.cus_id',
                array('law_code'=>'law_code', 'law_code_createdate' =>'law_code_createdate'))        
            
            ->order('payment_training_offline.payment_training_off_created_date')
            ->where('customers.cus_id = ?',$cus_id);
                        
        $row = $db->fetchAll($select);
        return $row;
    }

    public function loadPaymentLawyerOfflineToCreateCertification()
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
            ->from('payment_training_offline', array('payment_training_off_id'
            ,'payment_training_off_code'
            ,'payment_training_off_created_date'
            ,'payment_training_off_status'
            ,'payment_training_off_updatedate'         
            ,'bill_trainingoffline_id'))
            ->joinInner(
            'bill_training_offline',
            'bill_training_offline.bill_trainingoffline_id = payment_training_offline.bill_trainingoffline_id',
            array())         
            ->joinInner(
            'category_fee_training',
            'category_fee_training.category_fee_training_id = bill_training_offline.category_fee_training_id',
            array('name'=>'name','mooney'=>'mooney'))
            ->joinInner(
                'category_training',
                'category_training.cat_train_id = bill_training_offline.category_training_id',
                array('cat_train_name'=>'cat_train_name','cat_train_number'=>'cat_train_number'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_training_offline.cus_id',
                array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname')) 
            ->joinInner(
                'lawyer',
                'lawyer.cus_id = customers.cus_id',
                array('law_code'=>'law_code', 'law_code_createdate' =>'law_code_createdate'))        
            
            ->order('payment_training_offline.payment_training_off_created_date')
            ->where('payment_training_offline.payment_training_off_status = 1');
                        
        $row = $db->fetchAll($select);
        return $row;
    }


    public function loadPaymentTrainingOfflineById($id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        // $select = new Zend_Db_Select($db);
        $query = $db->select()
            ->from("payment_training_offline", array('payment_training_off_id'
            ,'payment_training_off_code'
            ,'payment_training_off_created_date'
            ,'payment_training_off_status'
            ,'payment_training_off_updatedate'
            ,'bill_trainingoffline_id'
            ,'amount'))
            ->joinInner(
            'bill_training_offline',
            'bill_training_offline.bill_trainingoffline_id = payment_training_offline.bill_trainingoffline_id',
            array())         
            ->joinInner(
            'category_fee_training',
            'category_fee_training.category_fee_training_id = bill_training_offline.category_fee_training_id',
            array('name'=>'name','mooney'=>'mooney'))
            // ->joinInner(
            //     'course',
            //     'course.course_id = bill_training_offline.course_id',
            //     array('course_name'=>'course_name'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_training_offline.cus_id',
                array('cus_birthday'=>'cus_birthday','cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))   
            ->where('payment_training_offline.payment_training_off_id = ?',$id)
            ->limit(1);   
                        
        return $db->fetchRow($query);
        // if (!$row) {
        //     return null;
        // }
        //return $row->toArray();
    }

    
    /*load oayment joining ofiline by cus id*/
    public function loadPaymentTrainingOfflineByCusId($cus_id)
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = new Zend_Db_Select($db);
        $select->distinct()
            ->from('payment_training_offline', array('payment_training_off_id'
            ,'payment_training_off_code'
            ,'payment_training_off_created_date'
            ,'payment_training_off_status'
            ,'payment_training_off_updatedate'
            ,'bill_trainingoffline_id'))
            ->joinInner(
            'bill_training_offline',
            'bill_training_offline.bill_trainingoffline_id = payment_training_offline.bill_trainingoffline_id',
            array())         
            ->joinInner(
            'category_fee_training',
            'category_fee_training.category_fee_training_id = bill_training_offline.category_fee_training_id',
            array('name'=>'name','mooney'=>'mooney'))
            // ->joinInner(
            //     'course',
            //     'course.course_id = bill_training_offline.course_id',
            //     array('course_name'=>'course_name'))
            ->joinInner(
                'customers',
                'customers.cus_id = bill_training_offline.cus_id',
                array('cus_firstname'=>'cus_firstname', 'cus_lastname' =>'cus_lastname'))    
            
            ->order('payment_training_offline.payment_training_off_created_date')
            ->where('customers.cus_id = ?',$cus_id);
                        
        $row = $db->fetchAll($select);
        return $row;
    }

}