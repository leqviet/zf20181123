<?php

class Akrabat_Db_Schema_Exception extends Zend_Db_Exception {}